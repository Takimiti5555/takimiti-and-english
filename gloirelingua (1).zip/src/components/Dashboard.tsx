import React, { useState } from 'react';
import { CATEGORIES, FLASHCARDS, CATEGORY_QUIZZES } from '../data';
import { CategoryKey, QuizQuestion, Flashcard, UserStats } from '../types';
import { 
  BookOpen, Languages, Edit3, MessageSquare, Sparkles, Zap, 
  Volume2, CheckCircle2, XCircle, ArrowRight, BookMarked, HelpCircle, RefreshCw 
} from 'lucide-react';

interface DashboardProps {
  stats: UserStats;
  onUpdateStats: (updater: (prev: UserStats) => UserStats) => void;
}

export default function Dashboard({ stats, onUpdateStats }: DashboardProps) {
  const [selectedCategory, setSelectedCategory] = useState<CategoryKey | null>(null);
  const [activeTab, setActiveTab] = useState<'topics' | 'flashcards' | 'quiz'>('topics');
  
  // Flashcards state
  const [currentFlashcardIndex, setCurrentFlashcardIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [learnedCardIds, setLearnedCardIds] = useState<string[]>([]);

  // QuizState
  const [currentQuizIndex, setCurrentQuizIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [typedAnswer, setTypedAnswer] = useState('');
  const [answerSubmitted, setAnswerSubmitted] = useState(false);
  const [answerCorrect, setAnswerCorrect] = useState<boolean | null>(null);
  const [quizScore, setQuizScore] = useState(0);
  const [quizComplete, setQuizComplete] = useState(false);

  const getCategoryIcon = (iconName: string) => {
    switch (iconName) {
      case 'BookOpen': return <BookOpen className="w-6 h-6" />;
      case 'Languages': return <Languages className="w-6 h-6" />;
      case 'Edit3': return <Edit3 className="w-6 h-6" />;
      case 'MessageSquare': return <MessageSquare className="w-6 h-6" />;
      case 'Sparkles': return <Sparkles className="w-6 h-6" />;
      case 'Zap': return <Zap className="w-6 h-6" />;
      default: return <BookOpen className="w-6 h-6" />;
    }
  };

  const handleCategorySelect = (id: CategoryKey) => {
    setSelectedCategory(id);
    setActiveTab(id === 'vocabulary' || id === 'idioms' ? 'flashcards' : 'topics');
    resetQuiz();
    setCurrentFlashcardIndex(0);
    setIsFlipped(false);
  };

  const speakText = (text: string) => {
    if ('speechSynthesis' in window) {
      // Cancel previous speech playing
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'en-US';
      utterance.rate = 0.85; // slightly slower for better listening practice
      window.speechSynthesis.speak(utterance);
    } else {
      alert("La synthèse vocale n'est pas prise en charge sur cet appareil.");
    }
  };

  const filteredFlashcards = FLASHCARDS.filter(
    card => card.category === selectedCategory || (selectedCategory === 'idioms' && card.type === 'Idiom')
  );

  const activeCategoryQuizzes = selectedCategory ? (CATEGORY_QUIZZES[selectedCategory] || []) : [];

  const handleFlashcardMastered = (cardId: string) => {
    if (!learnedCardIds.includes(cardId)) {
      setLearnedCardIds(prev => [...prev, cardId]);
      onUpdateStats(prev => ({
        ...prev,
        score: prev.score + 25,
        vocabularyMasteredCount: prev.vocabularyMasteredCount + 1
      }));
    }
    // Advance card
    handleNextFlashcard();
  };

  const handleNextFlashcard = () => {
    setIsFlipped(false);
    setTimeout(() => {
      if (filteredFlashcards.length > 0) {
        setCurrentFlashcardIndex(prev => (prev + 1) % filteredFlashcards.length);
      }
    }, 200);
  };

  // Quiz Handling
  const submitAnswer = () => {
    if (!selectedCategory || activeCategoryQuizzes.length === 0) return;
    const currentQuestion = activeCategoryQuizzes[currentQuizIndex];
    let isCorrect = false;

    if (currentQuestion.type === 'multiple' || currentQuestion.type === 'spelling') {
      isCorrect = selectedOption === currentQuestion.correctAnswer;
    } else {
      // Input text or direct translation comparison (trim & lowercase comparison)
      const cleanUser = typedAnswer.toLowerCase().trim().replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g,"");
      const cleanCorrect = currentQuestion.correctAnswer.toLowerCase().trim().replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g,"");
      isCorrect = cleanUser === cleanCorrect || cleanUser.includes(cleanCorrect) || cleanCorrect.includes(cleanUser);
    }

    setAnswerCorrect(isCorrect);
    setAnswerSubmitted(true);
    if (isCorrect) {
      setQuizScore(prev => prev + 1);
    }
  };

  const nextQuizQuestion = () => {
    setSelectedOption(null);
    setTypedAnswer('');
    setAnswerSubmitted(false);
    setAnswerCorrect(null);

    if (currentQuizIndex < activeCategoryQuizzes.length - 1) {
      setCurrentQuizIndex(prev => prev + 1);
    } else {
      setQuizComplete(true);
      // Give points & update indicators
      const finalPercentage = Math.round((quizScore / activeCategoryQuizzes.length) * 100);
      const wonPoints = quizScore * 30;
      onUpdateStats(prev => ({
        ...prev,
        score: prev.score + wonPoints,
        grammarSolvedCount: selectedCategory === 'grammar' ? prev.grammarSolvedCount + activeCategoryQuizzes.length : prev.grammarSolvedCount
      }));
    }
  };

  const resetQuiz = () => {
    setCurrentQuizIndex(0);
    setSelectedOption(null);
    setTypedAnswer('');
    setAnswerSubmitted(false);
    setAnswerCorrect(null);
    setQuizScore(0);
    setQuizComplete(false);
  };

  const currentCat = CATEGORIES.find(c => c.id === selectedCategory);

  return (
    <div className="w-full">
      {/* Category Selection Grid */}
      {!selectedCategory ? (
        <div>
          <div className="mb-6">
            <h2 className="text-2xl font-display text-slate-800 font-semibold">Vos modules d'apprentissage</h2>
            <p className="text-slate-500 text-sm mt-1">Sélectionnez une catégorie pour démarrer vos révisions interactives.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                id={`cat_card_${cat.id}`}
                onClick={() => handleCategorySelect(cat.id)}
                className="group relative text-left bg-white rounded-2xl p-6 border border-slate-100 hover:border-indigo-100 shadow-sm hover:shadow-md transition-all duration-300 overflow-hidden cursor-pointer flex flex-col justify-between h-[190px]"
              >
                <div className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-tr ${cat.color} opacity-5 rounded-bl-full group-hover:scale-110 transition-transform duration-500`}></div>
                
                <div>
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-tr ${cat.color} text-white flex items-center justify-center shadow-sm mb-4 group-hover:scale-110 transition-transform`}>
                    {getCategoryIcon(cat.icon)}
                  </div>
                  <h3 className="text-lg font-display font-bold text-slate-800 flex items-center gap-2">
                    {cat.title} 
                    <span className="text-xs font-normal text-slate-400 bg-slate-50 px-2 py-0.5 rounded-full font-sans border border-slate-100">
                      {cat.frenchTitle}
                    </span>
                  </h3>
                  <p className="text-slate-500 text-sm mt-1 line-clamp-2">{cat.description}</p>
                </div>

                <div className="flex items-center text-indigo-600 text-sm font-semibold mt-4 gap-1 transform group-hover:translate-x-1 transition-transform">
                  Réviser et s'exercer <ArrowRight className="w-4 h-4" />
                </div>
              </button>
            ))}
          </div>
        </div>
      ) : (
        /* Detailed Category Study View */
        <div className="bg-white rounded-3xl border border-slate-100 shadow-sm p-6 md:p-8 animate-fade-in">
          {/* Header */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-slate-100 pb-6 mb-6 gap-4">
            <div>
              <button 
                onClick={() => setSelectedCategory(null)}
                className="text-xs text-slate-400 hover:text-indigo-600 font-medium flex items-center gap-1 mb-2 Transition"
              >
                ← Retour au tableau de bord
              </button>
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-lg bg-gradient-to-tr ${currentCat?.color} text-white flex items-center justify-center shadow-sm`}>
                  {currentCat && getCategoryIcon(currentCat.icon)}
                </div>
                <h2 className="text-2xl font-display font-bold text-slate-800">
                  {currentCat?.title} <span className="text-sm font-normal text-slate-400 font-sans">({currentCat?.frenchTitle})</span>
                </h2>
              </div>
            </div>

            {/* Sub-Tabs Selector */}
            <div className="flex bg-slate-100 p-1 rounded-xl">
              {/* Optional Flashcards Tab if lists exist */}
              {filteredFlashcards.length > 0 && (
                <button
                  onClick={() => setActiveTab('flashcards')}
                  className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all ${
                    activeTab === 'flashcards' 
                      ? 'bg-white text-indigo-600 shadow-sm' 
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  Flashcards
                </button>
              )}
              <button
                onClick={() => setActiveTab('topics')}
                className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all ${
                  activeTab === 'topics' 
                    ? 'bg-white text-indigo-600 shadow-sm' 
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                Fiches de cours
              </button>
              {activeCategoryQuizzes.length > 0 && (
                <button
                  onClick={() => { setActiveTab('quiz'); resetQuiz(); }}
                  className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all ${
                    activeTab === 'quiz' 
                      ? 'bg-white text-indigo-600 shadow-sm' 
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  Exercices ({activeCategoryQuizzes.length})
                </button>
              )}
            </div>
          </div>

          {/* Tab Content: COURSE TOPICS */}
          {activeTab === 'topics' && currentCat && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {currentCat.topics.map((topic, i) => (
                <div key={i} className="border border-slate-100 rounded-2xl p-5 hover:border-slate-200 transition-colors bg-slate-50/50">
                  <h3 className="font-display font-bold text-slate-800 text-lg flex items-center gap-2">
                    <BookMarked className="w-5 h-5 text-indigo-500" />
                    {topic.title}
                  </h3>
                  <p className="text-slate-600 text-sm mt-2 leading-relaxed">{topic.description}</p>
                  
                  {topic.examples && topic.examples.length > 0 && (
                    <div className="mt-4 bg-white p-4 rounded-xl border border-slate-100">
                      <p className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Exemples pratiques :</p>
                      <ul className="space-y-3">
                        {topic.examples.map((ex, idx) => (
                          <li key={idx} className="flex items-start justify-between gap-3 text-sm text-slate-700 bg-slate-50 p-2.5 rounded-lg border border-slate-100/50">
                            <span className="flex-1 italic font-medium">"{ex}"</span>
                            <button 
                              onClick={() => speakText(ex.split('(')[0].trim())}
                              className="p-1 hover:bg-indigo-50 rounded-full text-slate-400 hover:text-indigo-600 transition"
                              title="Prononcer la phrase"
                            >
                              <Volume2 className="w-4 h-4" />
                            </button>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Tab Content: FLASHCARDS DECK */}
          {activeTab === 'flashcards' && filteredFlashcards.length > 0 && (() => {
            const currentCard = filteredFlashcards[currentFlashcardIndex];
            return (
              <div className="max-w-md mx-auto py-10 flex flex-col items-center">
                <p className="text-xs font-semibold text-slate-400 mb-4">
                  Flashcard {currentFlashcardIndex + 1} de {filteredFlashcards.length}
                </p>

                {/* Flip Card Container */}
                <div 
                  onClick={() => setIsFlipped(!isFlipped)}
                  className="w-full h-80 cursor-pointer relative perspective"
                >
                  <div className={`w-full h-full duration-500 preserve-3d relative ${isFlipped ? 'rotate-y-180' : ''}`}>
                    {/* Front side */}
                    <div className="absolute inset-0 w-full h-full bg-slate-900 text-white rounded-3xl p-8 flex flex-col justify-between shadow-lg border border-white/5 backface-hidden">
                      <div className="flex justify-between items-start">
                        <span className="text-xs font-bold tracking-wider uppercase text-indigo-400 bg-indigo-500/10 px-3 py-1 rounded-full border border-indigo-500/20">
                          {currentCard.type}
                        </span>
                        <HelpCircle className="w-5 h-5 text-slate-500" />
                      </div>
                      
                      <div className="text-center py-4">
                        <h4 className="text-3xl font-display font-bold tracking-tight mb-2">{currentCard.word}</h4>
                        <p className="text-slate-400 text-xs">Touchez la carte pour la retourner et voir l'explication</p>
                      </div>

                      <div className="flex justify-center">
                        <button 
                          onClick={(e) => { e.stopPropagation(); speakText(currentCard.word); }}
                          className="px-4 py-2 bg-white/10 hover:bg-white/20 rounded-full text-xs font-medium flex items-center gap-1 transition"
                        >
                          <Volume2 className="w-4 h-4" /> Écouter
                        </button>
                      </div>
                    </div>

                    {/* Back side */}
                    <div className="absolute inset-0 w-full h-full bg-white text-slate-800 rounded-3xl p-8 flex flex-col justify-between shadow-lg border border-slate-100 rotate-y-180 backface-hidden">
                      <div className="border-b border-slate-100 pb-2">
                        <span className="text-xs font-bold tracking-wider text-emerald-600 bg-emerald-50 px-2.5 py-0.5 rounded-full">
                          Traduction
                        </span>
                        <p className="text-xl font-bold font-display text-slate-800 mt-2">{currentCard.translation}</p>
                      </div>

                      <div className="my-4 bg-slate-50 p-4 rounded-xl border border-slate-100">
                        <p className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1">Mise en contexte :</p>
                        <p className="text-sm text-slate-700 italic font-medium">"{currentCard.example}"</p>
                        <p className="text-xs text-slate-500 mt-1 leading-relaxed">{currentCard.exampleTranslation}</p>
                      </div>

                      <div className="flex gap-2 justify-end">
                        <button 
                          onClick={(e) => { e.stopPropagation(); speakText(currentCard.example); }}
                          className="p-2 hover:bg-slate-100 rounded-lg text-slate-400 hover:text-slate-700 transition"
                          title="Prononcer l'exemple"
                        >
                          <Volume2 className="w-4.5 h-4.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Operations */}
                <div className="flex gap-4 mt-8 w-full max-w-sm justify-center">
                  <button 
                    onClick={handleNextFlashcard}
                    className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-semibold rounded-2xl transition"
                  >
                    Passer la carte
                  </button>
                  <button 
                    onClick={() => handleFlashcardMastered(currentCard.id)}
                    className="flex-1 py-3 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold rounded-2xl shadow-sm hover:shadow transition"
                  >
                    Maîtrisé (+25 XP)
                  </button>
                </div>
              </div>
            );
          })()}

          {/* Tab Content: QUIZ & DRILLS */}
          {activeTab === 'quiz' && activeCategoryQuizzes.length > 0 && (
            <div className="max-w-2xl mx-auto py-4">
              {!quizComplete ? (
                <div>
                  {/* Progress bar */}
                  <div className="flex justify-between items-center text-xs font-semibold text-slate-400 mb-2">
                    <span>Question {currentQuizIndex + 1} de {activeCategoryQuizzes.length}</span>
                    <span>Score: {quizScore} / {activeCategoryQuizzes.length}</span>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden mb-6">
                    <div 
                      className="bg-indigo-500 h-full transition-all duration-300"
                      style={{ width: `${((currentQuizIndex + 1) / activeCategoryQuizzes.length) * 100}%` }}
                    ></div>
                  </div>

                  {/* Question Box */}
                  <div className="bg-slate-50 border border-slate-100 rounded-2xl p-6 mb-6">
                    <span className="text-xs font-bold uppercase tracking-widest text-indigo-500 bg-indigo-50 border border-indigo-100 px-2.5 py-0.5 rounded-full">
                      {activeCategoryQuizzes[currentQuizIndex].context}
                    </span>
                    <h3 className="text-lg font-display text-slate-800 font-bold mt-4 whitespace-pre-line">
                      {activeCategoryQuizzes[currentQuizIndex].question}
                    </h3>

                    {/* Synthesized voice trigger for Listening question block */}
                    {activeCategoryQuizzes[currentQuizIndex].type === 'listening' && (
                      <div className="mt-4 flex items-center gap-4">
                        <button
                          onClick={() => speakText(activeCategoryQuizzes[currentQuizIndex].audioText || '')}
                          className="w-12 h-12 rounded-xl bg-orange-500 text-white flex items-center justify-center hover:bg-orange-600 active:scale-95 transition shadow-sm"
                        >
                          <Volume2 className="w-5 h-5 animate-pulse" />
                        </button>
                        <div>
                          <p className="text-sm font-bold text-orange-600">Exercice d'écoute audio</p>
                          <p className="text-xs text-slate-500">Cliquez sur le bouton pour écouter la dictée vocale, puis écrivez la réponse ci-dessous.</p>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Options Selector block for multiple choices or spelling */}
                  {(activeCategoryQuizzes[currentQuizIndex].type === 'multiple' || activeCategoryQuizzes[currentQuizIndex].type === 'spelling') && (
                    <div className="space-y-3 mb-6">
                      {activeCategoryQuizzes[currentQuizIndex].options?.map((option, idx) => (
                        <button
                          key={idx}
                          id={`quiz_opt_${idx}`}
                          disabled={answerSubmitted}
                          onClick={() => setSelectedOption(option)}
                          className={`w-full text-left p-4 rounded-xl border font-medium text-sm flex items-center justify-between transition-all ${
                            selectedOption === option 
                              ? 'border-indigo-500 bg-indigo-50/50 text-indigo-700' 
                              : 'border-slate-100 hover:border-slate-200 text-slate-600 hover:text-slate-800 bg-white'
                          }`}
                        >
                          <span>{option}</span>
                          <span className="w-5 h-5 rounded-full border border-slate-300 flex items-center justify-center text-xs">
                            {selectedOption === option && <span className="w-3 h-3 bg-indigo-600 rounded-full"></span>}
                          </span>
                        </button>
                      ))}
                    </div>
                  )}

                  {/* Manual Keyboard input block for translations or input questions */}
                  {(activeCategoryQuizzes[currentQuizIndex].type === 'input' || activeCategoryQuizzes[currentQuizIndex].type === 'translate' || activeCategoryQuizzes[currentQuizIndex].type === 'listening') && (
                    <div className="mb-6">
                      <label className="block text-xs font-bold text-slate-400 mb-2 uppercase tracking-wide">Tapez votre réponse :</label>
                      <input
                        type="text"
                        disabled={answerSubmitted}
                        value={typedAnswer}
                        onChange={(e) => setTypedAnswer(e.target.value)}
                        placeholder="Ex: writing here..."
                        className="w-full p-4 rounded-xl border border-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-200 focus:outline-none text-slate-800 font-medium font-sans"
                      />
                    </div>
                  )}

                  {/* Feedback on submit */}
                  {answerSubmitted && (
                    <div className={`p-4 rounded-xl border mb-6 flex items-start gap-3 animate-fade-in ${
                      answerCorrect 
                        ? 'border-emerald-200 bg-emerald-50 text-emerald-800' 
                        : 'border-red-200 bg-red-50 text-red-800'
                    }`}>
                      {answerCorrect ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                      ) : (
                        <XCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                      )}
                      <div>
                        <p className="font-bold text-sm">
                          {answerCorrect ? 'Excellente réponse ! (+30 XP)' : 'Aïe, ce n\'est pas tout à fait correct'}
                        </p>
                        <p className="text-xs mt-1 font-medium">{activeCategoryQuizzes[currentQuizIndex].explanation}</p>
                        {!answerCorrect && (
                          <p className="text-xs font-bold mt-2">
                            Réponse attendue : <span className="underline italic">"{activeCategoryQuizzes[currentQuizIndex].correctAnswer}"</span>
                          </p>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Actions buttons */}
                  <div className="flex gap-3 justify-end">
                    {!answerSubmitted ? (
                      <button
                        onClick={submitAnswer}
                        disabled={(!selectedOption && !typedAnswer.trim())}
                        className="px-6 py-3 bg-slate-900 text-white hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed font-semibold text-sm rounded-xl transition shadow-sm"
                      >
                        Soumettre la réponse
                      </button>
                    ) : (
                      <button
                        onClick={nextQuizQuestion}
                        className="px-6 py-3 bg-indigo-600 text-white hover:bg-indigo-700 font-semibold text-sm rounded-xl flex items-center gap-1.5 transition shadow"
                      >
                        Suivant <ArrowRight className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              ) : (
                /* Quiz Finished Splash screen */
                <div className="text-center py-8 animate-fade-in">
                  <div className="w-20 h-20 rounded-full bg-indigo-50 border border-indigo-100 flex items-center justify-center mx-auto mb-6 text-indigo-500">
                    <Sparkles className="w-10 h-10 animate-bounce" />
                  </div>
                  <h3 className="text-2xl font-display font-semibold text-slate-800">Module complété !</h3>
                  <p className="text-slate-500 mt-2 max-w-sm mx-auto">
                    Félicitations, vous venez de terminer la série de tests d'apprentissage pour la catégorie <span className="font-bold text-slate-800"> {currentCat?.frenchTitle}</span>.
                  </p>

                  <div className="my-6 max-w-xs mx-auto bg-slate-50 p-6 rounded-2xl border border-slate-100">
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Résultats obtenus</p>
                    <p className="text-4xl font-display font-bold text-indigo-600 mt-2">
                      {Math.round((quizScore / activeCategoryQuizzes.length) * 100)}%
                    </p>
                    <p className="text-sm font-semibold text-slate-700 mt-1">
                      {quizScore} réponses correctes sur {activeCategoryQuizzes.length}
                    </p>
                    <p className="text-xs text-emerald-600 mt-3 font-semibold bg-emerald-50 px-3 py-1 rounded-full inline-block border border-emerald-100">
                      XP Gagnés : +{quizScore * 30} XP
                    </p>
                  </div>

                  <div className="flex gap-4 justify-center">
                    <button
                      onClick={resetQuiz}
                      className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-sm rounded-xl transition flex items-center gap-1"
                    >
                      <RefreshCw className="w-4 h-4" /> Recommencer
                    </button>
                    <button
                      onClick={() => setSelectedCategory(null)}
                      className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm rounded-xl transition shadow"
                    >
                      Retour au tableau
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
