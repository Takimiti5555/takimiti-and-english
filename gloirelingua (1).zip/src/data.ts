import { CategoryDetail, Flashcard, QuizQuestion, FriendProfile, Challenge, TestResult, UserStats } from './types';

export const LEVEL_DETAILS = {
  beginner: {
    title: 'Beginner',
    label: 'Débutant (A1-A2)',
    badgeColor: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20',
    description: 'Bases solides, prononciation élémentaire et vocabulaire quotidien.'
  },
  advanced: {
    title: 'Advanced',
    label: 'Avancé (B1-B2)',
    badgeColor: 'bg-blue-500/10 text-blue-500 border-blue-500/20',
    description: 'Expression fluide, vocabulaire académique et compréhension de contextes complexes.'
  },
  professional: {
    title: 'Professional',
    label: 'Professionnel (C1-C2)',
    badgeColor: 'bg-purple-500/10 text-purple-500 border-purple-500/20',
    description: 'Compétences linguistiques de haut niveau, anglais des affaires, rédaction et conférences.'
  }
};

export const CATEGORIES: CategoryDetail[] = [
  {
    id: 'grammar',
    title: 'Grammar',
    frenchTitle: 'Grammaire',
    description: 'Maîtrisez les structures, les temps verbaux et les règles de base.',
    icon: 'BookOpen',
    color: 'from-blue-500 to-indigo-600',
    topics: [
      {
        title: 'Present Perfect vs Past Simple',
        description: 'Quand utiliser l\'action passée liée au présent vs l\'action complètement révolue.',
        examples: [
          'I have lived here for 5 years. (I still live here)',
          'I lived there for 5 years. (I do not live there anymore)'
        ]
      },
      {
        title: 'Prepositions of Place & Time (In, On, At)',
        description: 'Les prépositions essentielles pour localiser et dater sans faire de contresens.',
        examples: [
          'At 5 o\'clock / On Monday / In July',
          'At school / On the bus / In Paris'
        ]
      },
      {
        title: 'Conditional Sentences (0, 1st, 2nd, 3rd)',
        description: 'L\'expression d\'hypothèses de la réalité physique aux regrets intemporels.',
        examples: [
          'If you heat water, it boils. (0 Cond.)',
          'If it rains, we will stay home. (1st Cond.)',
          'If I won the lottery, I would buy a boat. (2nd Cond.)',
          'If I had studied harder, I would have passed. (3rd Cond.)'
        ]
      },
      {
        title: 'Articles: A, An, The & Zero Article',
        description: 'L\'utilisation correcte du défini, de l\'indéfini et de l\'omission de l\'article.',
        examples: [
          'She is a doctor. (Job)',
          'The moon is shining. (Unique)',
          'I love dogs. (General plural, no article)'
        ]
      }
    ]
  },
  {
    id: 'vocabulary',
    title: 'Vocabulary',
    frenchTitle: 'Vocabulaire',
    description: 'Étoffez vos phrases avec des termes parfaits pour tous les domaines.',
    icon: 'Languages',
    color: 'from-emerald-500 to-teal-600',
    topics: [
      {
        title: 'Vocabulaire Quotidien (Daily Life)',
        description: 'Mots essentiels pour faire des courses, voyager et interagir socialement.',
        examples: ['To commute (faire le trajet quotidien)', 'Groceries (courses alimentaires)', 'To catch up (se donner des nouvelles)']
      },
      {
        title: 'Vocabulaire Professionnel (Corporate English)',
        description: 'Indispensable pour négocier, faire des présentations et rédiger des e-mails.',
        examples: ['Leverage (tirer parti de)', 'Stakeholder (partie prenante)', 'Synergy (synergie)', 'To circles back (revenir sur un sujet)']
      },
      {
        title: 'Vocabulaire Académique (Academic Speech)',
        description: 'Écritures scientifiques, argumentations et structuration de mémoires.',
        examples: ['Concomitant (simultané, relié)', 'To hypothesize (émettre l\'hypothèse)', 'Empirical (empirique)']
      },
      {
        title: 'Vocabulaire Scientifique et Informatique (Tech Language)',
        description: 'Termes pointus pour le codage, l\'analyse de données et l\'IA.',
        examples: ['Algorithm (algorithme)', 'Deployment (déploiement)', 'Heuristics (heuristiques)']
      }
    ]
  },
  {
    id: 'spelling',
    title: 'Spelling',
    frenchTitle: 'Orthographe',
    description: 'Évitez les fautes courantes et testez votre précision.',
    icon: 'Edit3',
    color: 'from-amber-500 to-orange-600',
    topics: [
      {
        title: 'Silent Letters',
        description: 'Les pièges d\'orthographe où des lettres écrites ne s\'entendent pas.',
        examples: ['Knife (k muet)', 'Receipt (p muet)', 'Debt (b muet)', 'Wednesday (d muet)']
      },
      {
        title: 'Double Consonants',
        description: 'Difficulté classique liée au redoublement de consonnes.',
        examples: ['Necessary (un c, deux s)', 'Committee (deux m, deux t, deux e)', 'Accommodation']
      },
      {
        title: 'Homophones Confusion',
        description: 'Des mots qui s\'entendent pareil mais s\'écrivent différemment.',
        examples: ['Their vs There vs They\'re', 'Affect vs Effect', 'Accept vs Except']
      }
    ]
  },
  {
    id: 'expressions',
    title: 'Expressions',
    frenchTitle: 'Expressions Courantes',
    description: 'Exprimez-vous naturellement comme un natif au bureau ou à la maison.',
    icon: 'MessageSquare',
    color: 'from-purple-500 to-pink-600',
    topics: [
      {
        title: 'Expressions Courantes (Daily)',
        description: 'Façons idiomatiques de saluer, d\'approuver ou de s\'excuser.',
        examples: ['A piece of cake (C\'est un jeu d\'enfant)', 'Break a leg (Bonne chance)', 'Better late than never (Mieux vaut tard que jamais)']
      },
      {
        title: 'Expressions Professionnelles (Business)',
        description: 'Mises en situation professionnelles au bureau.',
        examples: ['To touch base (Prendre contact)', 'Keep me in the loop (Tiens-moi au courant)', 'To think outside the box (Penser différemment)']
      },
      {
        title: 'Expressions Académiques (Formal)',
        description: 'Formulations idéales pour introduire une idée de façon distinguée.',
        examples: ['On the contrary (Au contraire)', 'In the light of (Au vu de / à la lumière de)', 'With regard to (En ce qui concerne)']
      }
    ]
  },
  {
    id: 'idioms',
    title: 'Idioms',
    frenchTitle: 'Idiomatismes',
    description: 'Comprenez le sens caché derrière les métaphores anglaises réputées.',
    icon: 'Sparkles',
    color: 'from-indigo-500 to-purple-600',
    topics: [
      {
        title: 'Animal Idioms',
        description: 'Quand la langue fait habilement appel aux animaux.',
        examples: [
          'Let the cat out of the bag (Vendre la mèche)',
          'Wild goose chase (Une quête absurde/vaine)',
          'Hold your horses (Attends un peu, du calme)'
        ]
      },
      {
        title: 'Weather Idioms',
        description: 'Le temps météo comme métaphore de l\'humeur ou du destin.',
        examples: [
          'Under the weather (Se sentir un peu malade/mal)',
          'Every cloud has a silver lining (À quelque chose malheur est bon)',
          'Steal someone\'s thunder (Voler la vedette à quelqu\'un)'
        ]
      }
    ]
  },
  {
    id: 'slang',
    title: 'Slang & Argot',
    frenchTitle: 'Slang Actuel',
    description: 'L\'argot moderne issu des réseaux sociaux, de la culture pop US et UK.',
    icon: 'Zap',
    color: 'from-rose-500 to-red-600',
    topics: [
      {
        title: 'American Slang',
        description: 'Les expressions les plus fréquentes de la jeunesse américaine.',
        examples: ['Cap / No cap (Mensonge / Sans blague, juré)', 'Clout (Influence/célébrité)', 'Salty (Aigri, contrarié)']
      },
      {
        title: 'British Slang',
        description: 'L\'argot du Royaume-Uni pour frimer dans un pub à Londres.',
        examples: ['Mate (Ami/pote)', 'Chuffed (Ravi, super content)', 'Knackered (Épuisé, mort de fatigue)']
      },
      {
        title: 'Internet Slang',
        description: 'Acronymes et néologismes nés sur TikTok, Reddit et Instagram.',
        examples: ['GOAT (Greatest Of All Time - Le meilleur)', 'Rent free (Occuper l\'esprit en permanence)', 'Sus (Suspect)']
      }
    ]
  }
];

export const FLASHCARDS: Flashcard[] = [
  {
    id: 'f1',
    word: 'To leverage',
    type: 'Verb (Pro)',
    translation: 'Tirer parti de / Optimiser',
    example: 'We must leverage our technology assets to stay ahead.',
    exampleTranslation: 'Nous devons tirer parti de nos actifs technologiques pour rester en tête.',
    category: 'vocabulary'
  },
  {
    id: 'f2',
    word: 'Pristine',
    type: 'Adjective (Academic)',
    translation: 'Impeccable / Intact / Pur',
    example: 'The arctic tundra remains in a pristine state.',
    exampleTranslation: 'La toundra arctique demeure dans un état impeccable.',
    category: 'vocabulary'
  },
  {
    id: 'f3',
    word: 'Break a leg',
    type: 'Idiom',
    translation: 'Bonne chance ! (Surtout théâtre)',
    example: 'You have a presentation today? Break a leg!',
    exampleTranslation: 'Tu as une présentation aujourd\'hui ? Bonne chance !',
    category: 'idioms'
  },
  {
    id: 'f4',
    word: 'Salty',
    type: 'Slang',
    translation: 'Aigri / Contrarié pour un rien',
    example: 'He got salty because he lost the typing game.',
    exampleTranslation: 'Il s\'est vexé parce qu\'il a perdu la partie d\'écriture.',
    category: 'slang'
  },
  {
    id: 'f5',
    word: 'Empirical',
    type: 'Adjective (Scientific)',
    translation: 'Empirique / Basé sur l\'expérience',
    example: 'The team gathered empirical data to justify the theory.',
    exampleTranslation: 'L\'équipe a réuni des données empiriques pour étayer sa théorie.',
    category: 'vocabulary'
  },
  {
    id: 'f6',
    word: 'Under the weather',
    type: 'Idiom',
    translation: 'Un peu malade / Mal en point',
    example: 'She is staying home today because she feels under the weather.',
    exampleTranslation: 'Elle reste chez elle aujourd\'hui car elle se sent un peu malade.',
    category: 'idioms'
  }
];

export const CATEGORY_QUIZZES: Record<string, QuizQuestion[]> = {
  grammar: [
    {
      id: 'q_g1',
      type: 'multiple',
      question: 'Choose the correct form: "She ______ in Paris for three years, and she still lives there."',
      options: [
        'lived',
        'has lived',
        'is living',
        'lives'
      ],
      correctAnswer: 'has lived',
      explanation: 'On utilise le Present Perfect ("has lived") pour une action qui a commencé dans le passé et qui continue dans le présent.',
      context: 'Temps verbaux: Present Perfect'
    },
    {
      id: 'q_g2',
      type: 'multiple',
      question: 'Complete: "We need to finish this report. It needs to be ready ______ Monday."',
      options: [
        'at',
        'on',
        'by',
        'until'
      ],
      correctAnswer: 'by',
      explanation: '"By" indique la date limite (au plus tard le lundi), alors que "on" spécifie le jour précis.',
      context: 'Prépositions de temps'
    },
    {
      id: 'q_g3',
      type: 'translate',
      question: 'Traduisez cette phrase en anglais : "Si j\'avais plus de temps, j\'apprendrais la guitare."',
      correctAnswer: 'If I had more time, I would learn the guitar',
      explanation: 'Il s\'agit du Second Conditional (hypothèse imaginaire sur le présent) : If + Past Simple, would + base verbale.',
      context: 'Conditionnels'
    }
  ],
  vocabulary: [
    {
      id: 'q_v1',
      type: 'multiple',
      question: 'What is the corporate meaning of "to circle back"?',
      options: [
        'Dessiner des ronds dans un rapport',
        'Revenir à un sujet ou une personne plus tard',
        'Prendre un long vol de retour',
        'Changer d\'avis de manière unilatérale'
      ],
      correctAnswer: 'Revenir à un sujet ou une personne plus tard',
      explanation: '"To circle back" signifie que l\'on va rediscuter d\'un point précis ultérieurement.',
      context: 'Business English'
    },
    {
      id: 'q_v2',
      type: 'multiple',
      question: 'Le mot scientifique "HEURISTICS" fait référence à quoi ?',
      options: [
        'Des méthodes de calcul complexes et inchangeables',
        'Des raccourcis mentaux ou règles empiriques de résolution de problèmes',
        'L\'étude des langues anciennes disparues',
        'Des mesures de la pression atmosphérique'
      ],
      correctAnswer: 'Des raccourcis mentaux ou règles empiriques de résolution de problèmes',
      explanation: 'En sciences et IA, les heuristiques sont des approches d\'estimation rapide pour guider la résolution.',
      context: 'Vocabulaire Scientifique'
    }
  ],
  spelling: [
    {
      id: 'q_s1',
      type: 'spelling',
      question: 'Taper l\'orthographe correcte de ce mot (Qui signifie "Hébergement / Logement") :',
      options: ['Acomodation', 'Accommodation', 'Accomodation', 'Acommodation'],
      correctAnswer: 'Accommodation',
      explanation: '"Accommodation" prend deux "c" et deux "m". C\'est une erreur très courante.',
      context: 'Double Consonnes'
    },
    {
      id: 'q_s2',
      type: 'listening',
      question: 'Écoutez attentivement et tapez le mot prononcé : (Indice: Preuve d\'achat, ticket ou reçu. Contient une lettre muette "p")',
      audioText: 'receipt',
      correctAnswer: 'receipt',
      explanation: 'Le mot "receipt" (reçu) s\'écrit avec un "p" silencieux avant le "t".',
      context: 'Silent Letters'
    }
  ],
  expressions: [
    {
      id: 'q_e1',
      type: 'multiple',
      question: 'Que signifie l\'expression : "Keep me in the loop" ?',
      options: [
        'Tiens-moi au courant de la suite des événements',
        'Fais-moi tourner en bourrique',
        'Enregistre ma voix en boucle',
        'Ferme la boucle réseau immédiatement'
      ],
      correctAnswer: 'Tiens-moi au courant de la suite des événements',
      explanation: '"In the loop" veut dire "dans le cercle d\'information", donc informé des développements.',
      context: 'Expressions Professionnelles'
    }
  ],
  idioms: [
    {
      id: 'q_i1',
      type: 'multiple',
      question: 'Si quelqu\'un vous dit : "Let\'s not go on a wild goose chase", de quoi s\'agit-il ?',
      options: [
        'La chasse aux oies sauvages est interdite aujourd\'hui',
        'Ne nous lançons pas dans une recherche absurde et vouée à l\'échec',
        'Préparons une recette de cuisine traditionnelle',
        'Faisons l\'école buissonnière à la campagne'
      ],
      correctAnswer: 'Ne nous lançons pas dans une recherche absurde et vouée à l\'échec',
      explanation: '"A wild goose chase" est une poursuite laborieuse et futile d\'une chose inexistante ou d\'un but impossible.',
      context: 'Idiomes d\'animaux'
    }
  ],
  slang: [
    {
      id: 'q_sl1',
      type: 'multiple',
      question: 'Que signifie l\'expression d\'argot populaire "No cap" ?',
      options: [
        'Je n\'ai pas de casquette sur la tête',
        'Pas de mensonge, je jure que c\'est la vérité',
        'Il n\'y a pas de limite au budget',
        'Je n\'ai pas compris la plaisanterie'
      ],
      correctAnswer: 'Pas de mensonge, je jure que c\'est la vérité',
      explanation: '"Cap" signifie "mensonge", donc "no cap" veut dire "je ne mens pas" ou "sérieusement".',
      context: 'Argot Internet moderne'
    }
  ]
};

export const INITIAL_CHALLENGES: Challenge[] = [
  {
    id: 'ch1',
    title: 'Speed Vocab',
    type: 'vocabulary',
    description: 'Complétez 5 sessions de flashcards professionnelles sans faire la moindre erreur.',
    points: 150,
    badge: '🚀 Vocab King',
    completed: false
  },
  {
    id: 'ch2',
    title: 'Prononciation Orale',
    type: 'pronunciation',
    description: 'Enregistrez-vous en train de prononcer le virelangue "Peter Piper picked a peck of pickled peppers" sans fourcher.',
    points: 200,
    badge: '🗣️ Golden Voice',
    completed: false
  },
  {
    id: 'ch3',
    title: 'Dictée Parfaite',
    type: 'spelling',
    description: 'Complétez la dictée de spelling "Silent Letters" sans aucune faute d\'orthographe.',
    points: 180,
    badge: '✍️ Spelling Wizard',
    completed: true
  },
  {
    id: 'ch4',
    title: 'Maître des Idiomes',
    type: 'idioms',
    description: 'Résolvez 10 exercices de décryptage d\'idiomes anglais avancés.',
    points: 220,
    badge: '🔮 Idioms Guru',
    completed: false
  }
];

export const FRIEND_PROFILES: FriendProfile[] = [
  {
    id: 'fr1',
    name: 'Emma Johnson',
    level: 'advanced',
    country: 'United Kingdom',
    flag: '🇬🇧',
    interests: ['Grammar', 'Litérature', 'Pre-intermediate coaching', 'Casual Talk'],
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150',
    isOnline: true,
    score: 1240
  },
  {
    id: 'fr2',
    name: 'Hiroshi Tanaka',
    level: 'beginner',
    country: 'Japan',
    flag: '🇯🇵',
    interests: ['Business English', 'Scientific drafting', 'Gaming slang'],
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
    isOnline: true,
    score: 650
  },
  {
    id: 'fr3',
    name: 'Sofia Alvarez',
    level: 'professional',
    country: 'Spain',
    flag: '🇪🇸',
    interests: ['TOEFL Training', 'Speech pacing', 'Financial slang'],
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
    isOnline: false,
    score: 3400
  },
  {
    id: 'fr4',
    name: 'Amara Diop',
    level: 'advanced',
    country: 'Senegal',
    flag: '🇸🇳',
    interests: ['Academic English', 'Scientific papers', 'IELTS Grammar'],
    avatar: 'https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=150',
    isOnline: true,
    score: 1850
  }
];

export const ASSESSMENT_QUESTIONS: QuizQuestion[] = [
  {
    id: 't_q1',
    type: 'multiple',
    question: 'Reading Section: Read the passage below.\n\n"The rapid advance of deep learning models has revolutionized natural language processing, though it concomitantly raises crucial questions about compute budget limits."\n\nWhat is the closest synonym for the word "concomitantly" as used in the text?',
    options: [
      'Inversely / À l\'inverse',
      'Subsequently / Par la suite',
      'Simultaneously / Simultanément (au même moment)',
      'Accidentally / Accidentellement'
    ],
    correctAnswer: 'Simultanément (au même moment)',
    explanation: '"Concomitant" signifie qui accompagne ou se produit simultanément avec un autre fait.',
    context: 'Reading & Advanced Vocabulary'
  },
  {
    id: 't_q2',
    type: 'multiple',
    question: 'Grammar Section: Which conditional structure is correct for expressing past regrets that cannot be changed?',
    options: [
      'If I know, I will help you.',
      'If I knew, I would help you.',
      'If I had known, I would have helped you.',
      'If I had known, I would help you.'
    ],
    correctAnswer: 'If I had known, I would have helped you.',
    explanation: 'Le Third Conditional se structure avec "If + Past Perfect" et "would have + Past Participle" pour exprimer une hypothèse non réalisée dans le passé.',
    context: 'Grammar (Third Conditional)'
  },
  {
    id: 't_q3',
    type: 'listening',
    question: 'Listening Section: Listen to the spoken sentence carefully (by clicking the audio icon) and type exactly what you hear. (Hint: "The committee has approved the budget proposal.")',
    audioText: 'The committee has approved the budget proposal.',
    correctAnswer: 'The committee has approved the budget proposal.',
    explanation: 'La phrase évalue l\'accord d\'orthographe du mot difficile "committee" (double m, double t, double e).',
    context: 'Listening & Spelling'
  },
  {
    id: 't_q4',
    type: 'input',
    question: 'Writing Section: Complete the sentence using the correct preposition of place:\n"The keynote speaker is currently presenting ______ the auditorium."',
    correctAnswer: 'in',
    explanation: 'On utilise la préposition "in" pour un espace clos comme "the auditorium".',
    context: 'Writing & Prep of Place'
  },
  {
    id: 't_q5',
    type: 'multiple',
    question: 'Speaking & Pronunciation Section: Which of the following words has a silent "b"?',
    options: [
      'Obvious',
      'Cabinet',
      'Debt',
      'Bribe'
    ],
    correctAnswer: 'Debt',
    explanation: 'Dans le mot "debt" (dette) et "subtle" (subtil), la lettre "b" est complètement silencieuse.',
    context: 'Speaking & Ortho-Phonetics'
  }
];

export const INITIAL_STATS: UserStats = {
  score: 850,
  level: 'beginner',
  learningTimeMinutes: 120,
  testsCompletedCount: 2,
  challengesCompletedCount: 3,
  vocabularyMasteredCount: 14,
  grammarSolvedCount: 8,
  attendanceStreak: 4,
  badges: ['🏆 Premier Pas', '✍️ Spelling Wizard', '🌍 Explorateur']
};
