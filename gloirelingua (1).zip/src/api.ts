import { ChatMessage } from './types';

/**
 * Sends messages to our custom server-side Gemini tutor API endpoint
 */
export async function sendChatMessage(messages: { role: 'user' | 'model'; content: string }[], userLevel: string): Promise<string> {
  const response = await fetch('/api/chat', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      messages: messages.map(m => ({
        role: m.role,
        content: m.content
      })),
      userLevel,
    })
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.error || 'Impossible de communiquer avec le tuteur IA.');
  }

  const data = await response.json();
  return data.content;
}

/**
 * Calls the AI text analyzer to correct a phrase or paragraph
 */
export async function correctUserText(text: string, userLevel: string): Promise<string> {
  const response = await fetch('/api/correct', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      text,
      userLevel,
    })
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.error || "La correction par l'IA a échoué.");
  }

  const data = await response.json();
  return data.analysis;
}
