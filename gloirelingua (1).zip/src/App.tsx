import React, { useState, useEffect, useRef } from 'react';
import { 
  BookOpen, Languages, Sparkles, MessageSquare, Zap, Target, BarChart3, 
  Menu, X, GraduationCap, Trophy, Award, Calendar, Volume2, Send, 
  Search, Users, Phone, Video, Shield, Check, ListChecks, FileText, 
  HelpCircle, AlertCircle, Play, Bell, Upload, Trash2, Printer, MapPin, Laptop, Cpu
} from 'lucide-react';
import { CATEGORIES, FRIEND_PROFILES, INITIAL_CHALLENGES, INITIAL_STATS, ASSESSMENT_QUESTIONS } from './data';
import { UserStats, ChatMessage, ChatRoom, FriendProfile, Challenge, TestResult, UserLevel } from './types';
import Dashboard from './components/Dashboard';
import { sendChatMessage, correctUserText } from './api';

export default function App() {
  // Navigation & Onboarding States
  const [isOnboarded, setIsOnboarded] = useState<boolean>(false);
  const [userName, setUserName] = useState<string>('');
  const [userSelectedLevel, setUserSelectedLevel] = useState<UserLevel>('beginner');
  const [currentSection, setCurrentSection] = useState<'dashboard' | 'ai' | 'community' | 'challenges' | 'test' | 'stats'>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);
  
  // Custom user stats
  const [stats, setStats] = useState<UserStats>(INITIAL_STATS);

  // Active Chats with Gemini AI
  const [aiChatMessages, setAiChatMessages] = useState<Array<{ role: 'user' | 'model'; content: string }>>([
    { role: 'model', content: "Hello! Je suis GLOIRElingua AI, votre tuteur d'anglais personnel. Je peux vous expliquer des règles de grammaire complexes, traduire du texte, corriger vos fautes d’orthographe et vous entraîner à l'anglais professionnel ou technique. De quoi souhaiteriez-vous discuter aujourd'hui ?" }
  ]);
  const [aiInputValue, setAiInputValue] = useState<string>('');
  const [aiLoading, setAiLoading] = useState<boolean>(false);
  
  // Custom Text Analyzer State
  const [textToCorrect, setTextToCorrect] = useState<string>('');
  const [correctionAnalysis, setCorrectionAnalysis] = useState<string>('');
  const [correctionLoading, setCorrectionLoading] = useState<boolean>(false);

  // Community State
  const [friends, setFriends] = useState<FriendProfile[]>(FRIEND_PROFILES);
  const [selectedFriend, setSelectedFriend] = useState<FriendProfile | null>(FRIEND_PROFILES[0]);
  const [communitySearch, setCommunitySearch] = useState<string>('');
  const [filterLevel, setFilterLevel] = useState<string>('all');
  const [directMessages, setDirectMessages] = useState<Record<string, ChatMessage[]>>({
    'fr1': [
      { id: '1', senderId: 'fr1', senderName: 'Emma Johnson', senderAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150', text: "Hi! Are you ready for our dialogue practice today?", timestamp: "10:15" }
    ],
    'fr2': [
      { id: '1', senderId: 'fr2', senderName: 'Hiroshi Tanaka', senderAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150', text: "Hello, can you help me check if this sentence is correct?", timestamp: "09:30" }
    ]
  });
  const [chatInputValue, setChatInputValue] = useState<string>('');
  
  // Attachment Simulation
  const [attachedFile, setAttachedFile] = useState<{ name: string; size: string } | null>(null);

  // Call Simulation States (Voice & Video)
  const [activeCall, setActiveCall] = useState<{
    type: 'voice' | 'video';
    partner: FriendProfile;
    status: 'connecting' | 'active' | 'disconnected';
    streamGranted: boolean;
  } | null>(null);
  
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [callDuration, setCallDuration] = useState<number>(0);
  const [audioMeter, setAudioMeter] = useState<number>(30); // Dynamic speaking pulse
  const [localCamMuted, setLocalCamMuted] = useState<boolean>(false);
  const [localMicMuted, setLocalMicMuted] = useState<boolean>(false);

  // Challenges State
  const [challenges, setChallenges] = useState<Challenge[]>(INITIAL_CHALLENGES);
  
  // Vocabulary mini-game challenge
  const [miniGameActive, setMiniGameActive] = useState<boolean>(false);
  const [miniGameStep, setMiniGameStep] = useState<number>(0);
  const [miniGameScore, setMiniGameScore] = useState<number>(0);
  const [miniGameWords] = useState([
    { word: "To commute", options: ["Faire la cuisine", "Faire le trajet domicile-travail", "S'engager activement", "Échanger de l'argent"], correct: 1 },
    { word: "Stakeholder", options: ["Une poêle à frire", "Un investisseur anonyme", "Une partie prenante / collaborateur", "Un garde-forestier"], correct: 2 },
    { word: "Pristine", options: ["Précieux", "Ancien", "Mystique", "Impeccable / Intact / Pur"], correct: 3 },
    { word: "Salty", options: ["Poivré", "Aigri / Contrarié", "Gourmand", "Océanique"], correct: 1 }
  ]);

  // Test / Assessment State
  const [testActive, setTestActive] = useState<boolean>(false);
  const [testStep, setTestStep] = useState<number>(0);
  const [testAnswers, setTestAnswers] = useState<Record<string, string>>({});
  const [testResults, setTestResults] = useState<TestResult[]>([
    {
      id: "res_init_1",
      date: "01/06/2026",
      score: 60,
      estimatedLevel: "beginner",
      breakdown: { reading: 55, writing: 65, listening: 40, speaking: 50, grammar: 70, vocabulary: 60 },
      analysis: "Bonne maîtrise des règles de base. Les compétences d'écoute orale active et l'anglais professionnel familier nécessitent une pratique plus ciblée."
    }
  ]);
  const [viewingResult, setViewingResult] = useState<TestResult | null>(null);

  // Mock Notifications
  const [notifications, setNotifications] = useState([
    { id: '1', title: '🎯 Défi du Jour', message: 'Résolvez 3 quiz de niveau avancé pour doubler vos points d’expérience !', read: false },
    { id: '2', title: '💬 Nouveau message', message: 'Emma vient de t\'envoyer un enregistrement audio pour pratiquer.', read: true },
    { id: '3', title: '📈 Bilan Hebdomadaire disponible', message: 'Votre niveau estimé a augmenté grâce à votre assiduité.', read: true }
  ]);
  const [showNotificationsDropdown, setShowNotificationsDropdown] = useState<boolean>(false);

  // Load existing profile from local storage if available
  useEffect(() => {
    const savedName = localStorage.getItem('gloireName');
    const savedLevel = localStorage.getItem('gloireLevel');
    if (savedName) {
      setUserName(savedName);
      setIsOnboarded(true);
      if (savedLevel) {
        setUserSelectedLevel(savedLevel as UserLevel);
        setStats(prev => ({ ...prev, level: savedLevel as UserLevel }));
      }
    }
  }, []);

  const handleStartApp = (nameToUse: string, levelToUse: UserLevel) => {
    const trimmed = nameToUse.trim() || 'Apprenant GLOIRE';
    setUserName(trimmed);
    setUserSelectedLevel(levelToUse);
    setIsOnboarded(true);
    setStats(prev => ({
      ...prev,
      level: levelToUse
    }));
    localStorage.setItem('gloireName', trimmed);
    localStorage.setItem('gloireLevel', levelToUse);
  };

  const handleRestartApp = () => {
    localStorage.clear();
    setUserName('');
    setIsOnboarded(false);
    setCurrentSection('dashboard');
  };

  // Chat with Gemini AI Tutor
  const sendAiMessage = async () => {
    if (!aiInputValue.trim() || aiLoading) return;
    
    const userMsg = aiInputValue.trim();
    setAiInputValue('');
    
    // Add user message to historical array
    const updatedMessages = [...aiChatMessages, { role: 'user' as const, content: userMsg }];
    setAiChatMessages(updatedMessages);
    setAiLoading(true);

    try {
      const gptReply = await sendChatMessage(updatedMessages, stats.level);
      setAiChatMessages(prev => [...prev, { role: 'model', content: gptReply }]);
      
      // Reward experience points for interacting with AI (5 points per interaction)
      setStats(prev => ({
        ...prev,
        score: prev.score + 10,
        learningTimeMinutes: prev.learningTimeMinutes + 2
      }));
    } catch (err: any) {
      console.error(err);
      setAiChatMessages(prev => [
        ...prev, 
        { role: 'model', content: `⚠️ Oups, je rencontre un problème de connexion avec le serveur. Assurez-vous d'avoir inséré une clé API valide dans l'onglet **Settings**.\n\nDétails de l'erreur : ${err.message || 'Service indisponible'}` }
      ]);
    } finally {
      setAiLoading(false);
    }
  };

  // Deep phrase correction
  const handleCorrectText = async () => {
    if (!textToCorrect.trim() || correctionLoading) return;
    setCorrectionLoading(true);
    try {
      const result = await correctUserText(textToCorrect, stats.level);
      setCorrectionAnalysis(result);
      setStats(prev => ({
        ...prev,
        score: prev.score + 15,
        grammarSolvedCount: prev.grammarSolvedCount + 1
      }));
    } catch (err: any) {
      setCorrectionAnalysis(`⚠️ Une erreur est survenue lors de l'analyse linguistique. \nErreur: ${err.message}`);
    } finally {
      setCorrectionLoading(false);
    }
  };

  // Peer-to-peer Chat Message Dispatcher
  const handleSendChatMessage = () => {
    if (!selectedFriend || (!chatInputValue.trim() && !attachedFile)) return;

    const newMessage: ChatMessage = {
      id: Date.now().toString(),
      senderId: 'user',
      senderName: userName,
      senderAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150',
      text: chatInputValue,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      fileName: attachedFile?.name,
      fileUrl: attachedFile ? '#' : undefined
    };

    const friendId = selectedFriend.id;
    const currentMsgs = directMessages[friendId] || [];
    const updatedMsgs = [...currentMsgs, newMessage];

    setDirectMessages({
      ...directMessages,
      [friendId]: updatedMsgs
    });

    setChatInputValue('');
    setAttachedFile(null);

    // Simulated response from friend after 2 seconds to make the classroom alive
    setTimeout(() => {
      const replies = [
        "That's so interesting! I completely agree with you on that point.",
        "Oh, that's beautiful! Thanks for sharing that explanation with me.",
        "How is your preparation going for our next English exam?",
        "Excellent sentence! Let's schedule our next voice call to work on pronunciation.",
        "That's actually a very common slang in my country!"
      ];
      const randomReply = replies[Math.floor(Math.random() * replies.length)];

      const automatedReply: ChatMessage = {
        id: (Date.now() + 1).toString(),
        senderId: friendId,
        senderName: selectedFriend.name,
        senderAvatar: selectedFriend.avatar,
        text: randomReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setDirectMessages(prev => ({
        ...prev,
        [friendId]: [...(prev[friendId] || []), automatedReply]
      }));

      // Gain +10 points for communicating in the social space
      setStats(prev => ({
        ...prev,
        score: prev.score + 10
      }));
    }, 2000);
  };

  // Simulated Web-Cam & Mic Streaming Audio/Video Calls
  const triggerCall = async (type: 'voice' | 'video', partner: FriendProfile) => {
    setActiveCall({
      type,
      partner,
      status: 'connecting',
      streamGranted: false
    });
    setCallDuration(0);

    // Try and prompt stream permissions to let users play with it
    try {
      const constraints = {
        audio: true,
        video: type === 'video'
      };
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      
      // Update Call to Connected once access is granted
      setActiveCall(prev => prev ? { ...prev, status: 'active', streamGranted: true } : null);
      
      // Setup Local Cam Video element
      setTimeout(() => {
        if (videoRef.current && stream) {
          videoRef.current.srcObject = stream;
          videoRef.current.play().catch(e => console.warn(e));
        }
      }, 500);

    } catch (e) {
      console.warn("Utilisateur a refusé ou n'a pas sélectionné la caméra/micro. Fonctionnement en mode simulation active.");
      // Soft fail fallback - continue the simulation without real hardware stream
      setActiveCall(prev => prev ? { ...prev, status: 'active', streamGranted: false } : null);
    }
  };

  // Dynamic spectrogram ticker for the active call
  useEffect(() => {
    let interval: any;
    if (activeCall && activeCall.status === 'active') {
      interval = setInterval(() => {
        setCallDuration(prev => prev + 1);
        setAudioMeter(Math.floor(Math.random() * 80) + 15);
      }, 1000);
    } else {
      setCallDuration(0);
    }
    return () => clearInterval(interval);
  }, [activeCall]);

  const endCall = () => {
    if (activeCall?.streamGranted && videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
    }
    setActiveCall(null);
    // Reward points for practice
    const practiceXp = Math.min(callDuration * 5, 200);
    if (practiceXp > 0) {
      setStats(p => ({
        ...p,
        score: p.score + Number(practiceXp),
        learningTimeMinutes: p.learningTimeMinutes + Math.ceil(callDuration / 60)
      }));
    }
  };

  // Mock File Drag and Drop / Selection handler for chat
  const handleChatFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setAttachedFile({
        name: file.name,
        size: (file.size / 1024).toFixed(1) + ' KB'
      });
    }
  };

  // Quizz assessment handling
  const handleTestSelection = (questionId: string, answer: string) => {
    setTestAnswers({
      ...testAnswers,
      [questionId]: answer
    });
  };

  const submitFinalAssessment = () => {
    // Calcul score
    let scoreGained = 0;
    ASSESSMENT_QUESTIONS.forEach(q => {
      const cleanUser = (testAnswers[q.id] || '').toLowerCase().trim();
      const cleanCorrect = q.correctAnswer.toLowerCase().trim();
      if (cleanUser === cleanCorrect || cleanUser.includes(cleanCorrect) || cleanCorrect.includes(cleanUser)) {
        scoreGained += 20; // 5 questions * 20 points = 100
      }
    });

    // Estimate professional level
    let estimated: UserLevel = 'beginner';
    if (scoreGained >= 80) estimated = 'professional';
    else if (scoreGained >= 50) estimated = 'advanced';

    const cleanBreakdown = {
      reading: scoreGained >= 80 ? 90 : (scoreGained >= 50 ? 70 : 45),
      writing: testAnswers['t_q4'] ? 95 : 50,
      listening: testAnswers['t_q3'] ? 90 : 35,
      speaking: scoreGained > 60 ? 80 : 40,
      grammar: scoreGained >= 80 ? 95 : 60,
      vocabulary: scoreGained >= 50 ? 85 : 45
    };

    const newResult: TestResult = {
      id: 'res_' + Date.now(),
      date: new Date().toLocaleDateString('fr-FR'),
      score: scoreGained,
      estimatedLevel: estimated,
      breakdown: cleanBreakdown,
      analysis: scoreGained >= 80 
        ? "Excellent niveau global. Vous maîtrisez le jargon universitaire, les idiomes avancés et la formulation professionnelle. Prêt pour des challenges d'affaires." 
        : (scoreGained >= 50 
          ? "Bonne maîtrise intermédiaire. Des lacunes mineures en prononciation et tournures idiomatisées persistent mais le niveau général est très fluide."
          : "Niveau débutant à consolider. Concentrez-vous sur l'apprentissage quotidien, les flashcards et la maîtrise du Present Perfect dans notre module Grammar.")
    };

    setTestResults([newResult, ...testResults]);
    setTestActive(false);
    setViewingResult(newResult);
    
    // Update active stats
    setStats(prev => ({
      ...prev,
      level: estimated,
      score: prev.score + 500, // BIG XP payout
      testsCompletedCount: prev.testsCompletedCount + 1,
      grammarSolvedCount: prev.grammarSolvedCount + 3,
      vocabularyMasteredCount: prev.vocabularyMasteredCount + 5
    }));
  };

  // Speaking Pronunciation test helper for exams
  const speakExamSentence = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'en-US';
      utterance.rate = 0.85;
      window.speechSynthesis.speak(utterance);
    }
  };

  // Challenges mini gameplay engine
  const handleMiniGameAnswer = (selectedIdx: number) => {
    const isCorrect = selectedIdx === miniGameWords[miniGameStep].correct;
    if (isCorrect) {
      setMiniGameScore(prev => prev + 1);
    }
    
    if (miniGameStep < miniGameWords.length - 1) {
      setMiniGameStep(prev => prev + 1);
    } else {
      // Finished
      const finalGains = (miniGameScore + (isCorrect ? 1 : 0)) * 50;
      setStats(prev => ({
        ...prev,
        score: prev.score + finalGains,
        challengesCompletedCount: prev.challengesCompletedCount + 1,
        vocabularyMasteredCount: prev.vocabularyMasteredCount + 3
      }));

      // Mark challenge completed
      setChallenges(prev => prev.map(ch => ch.id === 'ch1' ? { ...ch, completed: true } : ch));
      setMiniGameActive(false);
      alert(`Bravo ! Défi complété. Score : ${miniGameScore + (isCorrect ? 1 : 0)}/${miniGameWords.length}. Vous gagnez +${finalGains} points d'expérience !`);
    }
  };

  // Level advancement helpers based on score
  const getProgressPercentage = () => {
    const nextLimit = stats.level === 'beginner' ? 1500 : (stats.level === 'advanced' ? 4000 : 8000);
    const prevLimit = stats.level === 'beginner' ? 0 : (stats.level === 'advanced' ? 1500 : 4000);
    const range = nextLimit - prevLimit;
    const accomplished = stats.score - prevLimit;
    return Math.min(Math.max(Math.round((accomplished / range) * 100), 5), 100);
  };

  // Simulated Friend filter logic
  const filteredFriends = friends.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(communitySearch.toLowerCase()) || 
                          item.interests.some(i => i.toLowerCase().includes(communitySearch.toLowerCase()));
    const matchesLevel = filterLevel === 'all' || item.level === filterLevel;
    return matchesSearch && matchesLevel;
  });

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-800 flex flex-col">
      
      {/* 1. ONBOARDING WELCOME SCREEN */}
      {!isOnboarded ? (
        <div className="flex-1 flex flex-col items-center justify-center p-4 max-w-4xl mx-auto">
          {/* Header Branding */}
          <div className="text-center mb-8 animate-fade-in">
            <div className="w-20 h-20 bg-gradient-to-tr from-indigo-600 to-blue-500 rounded-3xl flex items-center justify-center mx-auto mb-4 shadow-xl shadow-indigo-600/10 text-white transform hover:rotate-12 duration-300">
              <GraduationCap className="w-11 h-11" />
            </div>
            <h1 className="text-4xl md:text-5xl font-display font-extrabold tracking-tight text-slate-900">
              GLOIRE<span className="text-indigo-600">lingua</span>
            </h1>
            <p className="text-slate-500 text-sm md:text-base mt-2 max-w-md mx-auto">
              La plateforme mobile d'apprentissage de l'anglais modernisée, propulsée par l'intelligence artificielle.
            </p>
          </div>

          {/* Form Card */}
          <div className="w-full max-w-md bg-white p-8 rounded-3xl border border-slate-100 shadow-xl shadow-slate-100/50">
            <h2 className="text-xl font-display font-bold text-slate-800 mb-6 flex items-center gap-2">
              <Shield className="w-5 h-5 text-indigo-600" /> Commencer immédiatement
            </h2>

            <div className="space-y-5">
              {/* Name Input */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Votre Nom / Pseudo</label>
                <input 
                  type="text"
                  placeholder="Ex: Alexandre GLOIRE"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  className="w-full p-4 rounded-xl border border-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-100 focus:outline-none font-medium"
                />
              </div>

              {/* Path / Level Selection */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">Sélectionnez votre niveau initial</label>
                <div className="grid grid-cols-1 gap-3">
                  <button 
                    onClick={() => setUserSelectedLevel('beginner')}
                    className={`p-4 rounded-2xl border text-left flex items-start gap-3 transition-all ${
                      userSelectedLevel === 'beginner' 
                        ? 'border-indigo-600 bg-indigo-50/50 ring-1 ring-indigo-500' 
                        : 'border-slate-100 hover:border-slate-200'
                    }`}
                  >
                    <span className="p-2 bg-emerald-50 text-emerald-600 font-bold rounded-lg text-xs mt-0.5">A1</span>
                    <div>
                      <p className="font-bold text-slate-800 text-sm">Débutant (Beginner)</p>
                      <p className="text-xs text-slate-400 mt-0.5">Bases de grammaire, dialogues quotidiens, vocabulaire essentiel.</p>
                    </div>
                  </button>

                  <button 
                    onClick={() => setUserSelectedLevel('advanced')}
                    className={`p-4 rounded-2xl border text-left flex items-start gap-3 transition-all ${
                      userSelectedLevel === 'advanced' 
                        ? 'border-indigo-600 bg-indigo-50/50 ring-1 ring-indigo-500' 
                        : 'border-slate-100 hover:border-slate-200'
                    }`}
                  >
                    <span className="p-2 bg-blue-50 text-blue-600 font-bold rounded-lg text-xs mt-0.5">B2</span>
                    <div>
                      <p className="font-bold text-slate-800 text-sm">Avancé (Advanced)</p>
                      <p className="text-xs text-slate-400 mt-0.5">Anglais fluide, rédactions techniques, expressions idiomatiques.</p>
                    </div>
                  </button>

                  <button 
                    onClick={() => setUserSelectedLevel('professional')}
                    className={`p-4 rounded-2xl border text-left flex items-start gap-3 transition-all ${
                      userSelectedLevel === 'professional' 
                        ? 'border-indigo-600 bg-indigo-50/50 ring-1 ring-indigo-500' 
                        : 'border-slate-100 hover:border-slate-200'
                    }`}
                  >
                    <span className="p-2 bg-purple-50 text-purple-600 font-bold rounded-lg text-xs mt-0.5 font-display">C1</span>
                    <div>
                      <p className="font-bold text-slate-800 text-sm">Professionnel (Professional)</p>
                      <p className="text-xs text-slate-400 mt-0.5">Anglais des affaires, recherche, colloques et management complexe.</p>
                    </div>
                  </button>
                </div>
              </div>

              {/* Start Button */}
              <button
                onClick={() => handleStartApp(userName, userSelectedLevel)}
                className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-2xl transition shadow-lg shadow-indigo-600/10 hover:shadow-indigo-600/20 mt-2 cursor-pointer flex items-center justify-center gap-2"
              >
                Commencer l'apprentissage <ArrowIcon />
              </button>
            </div>
          </div>

          <div className="mt-8 flex gap-6 text-slate-400 text-xs items-center">
            <span className="flex items-center gap-1"><Shield className="w-3.5 h-3.5" /> Sécurisé par Gemini IA</span>
            <span>•</span>
            <span>Pas de compte requis</span>
          </div>
        </div>
      ) : (
        
        /* 2. CHIEFLY MAIN WORKSPACE (AUTHENTICATED) */
        <div className="flex-1 flex flex-col md:flex-row relative">
          
          {/* DESKTOP SIDEBAR */}
          <aside className="w-64 bg-slate-900 text-white hidden md:flex flex-col border-r border-slate-800 shrink-0 select-none">
            {/* Brand Logo */}
            <div className="p-5 border-b border-slate-850 flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white">
                <GraduationCap className="w-5 h-5" />
              </div>
              <span className="text-xl font-display font-extrabold tracking-tight">
                GLOIRE<span className="text-indigo-400">lingua</span>
              </span>
            </div>

            {/* Nav List */}
            <nav className="flex-1 p-4 space-y-1.5 overflow-y-auto">
              <button 
                onClick={() => { setCurrentSection('dashboard'); setIsSidebarOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition font-medium text-sm text-left ${
                  currentSection === 'dashboard' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <BookOpen className="w-4.5 h-4.5" /> Tableau de bord
              </button>
              
              <button 
                onClick={() => { setCurrentSection('ai'); setIsSidebarOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition font-medium text-sm text-left ${
                  currentSection === 'ai' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Sparkles className="w-4.5 h-4.5" /> Assistant Tuteur IA
              </button>

              <button 
                onClick={() => { setCurrentSection('community'); setIsSidebarOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition font-medium text-sm text-left ${
                  currentSection === 'community' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Users className="w-4.5 h-4.5" /> Communauté & Clubs
              </button>

              <button 
                onClick={() => { setCurrentSection('challenges'); setIsSidebarOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition font-medium text-sm text-left ${
                  currentSection === 'challenges' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Target className="w-4.5 h-4.5" /> Défis & Badges
              </button>

              <button 
                onClick={() => { setCurrentSection('test'); setIsSidebarOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition font-medium text-sm text-left ${
                  currentSection === 'test' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Award className="w-4.5 h-4.5" /> Évaluations & Examens
              </button>

              <button 
                onClick={() => { setCurrentSection('stats'); setIsSidebarOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition font-medium text-sm text-left ${
                  currentSection === 'stats' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <BarChart3 className="w-4.5 h-4.5" /> Rapports & Certificat
              </button>
            </nav>

            {/* Profile Summary footer */}
            <div className="p-4 border-t border-slate-850 bg-slate-950/40">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-full bg-slate-700 border border-slate-650 flex items-center justify-center font-bold text-indigo-400">
                  {userName.charAt(0).toUpperCase()}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold truncate text-slate-100">{userName}</p>
                  <p className="text-xs text-slate-400 uppercase tracking-wider font-bold">Niveau: {stats.level}</p>
                </div>
              </div>
              <button 
                onClick={handleRestartApp}
                className="w-full text-center text-xs font-semibold py-1.5 text-slate-500 hover:text-red-400 transition"
              >
                Réinitialisation
              </button>
            </div>
          </aside>

          {/* MOBILE NAVIGATION OVERLAY / SIDEBAR */}
          {isSidebarOpen && (
            <div className="fixed inset-0 bg-slate-900/85 z-50 flex md:hidden animate-fade-in">
              <div className="w-72 bg-slate-900 text-white h-full p-5 flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-center mb-6">
                    <span className="text-xl font-display font-extrabold text-white">GLOIRElingua</span>
                    <button onClick={() => setIsSidebarOpen(false)} className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700">
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                  
                  <nav className="space-y-2">
                    {/* Same items */}
                    <button 
                      onClick={() => { setCurrentSection('dashboard'); setIsSidebarOpen(false); }}
                      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left font-semibold ${
                        currentSection === 'dashboard' ? 'bg-indigo-600 text-white' : 'text-slate-350 hover:bg-slate-800'
                      }`}
                    >
                      <BookOpen className="w-5 h-5" /> Tableau de bord
                    </button>
                    <button 
                      onClick={() => { setCurrentSection('ai'); setIsSidebarOpen(false); }}
                      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left font-semibold ${
                        currentSection === 'ai' ? 'bg-indigo-600 text-white' : 'text-slate-350 hover:bg-slate-800'
                      }`}
                    >
                      <Sparkles className="w-5 h-5" /> Assistant Tuteur IA
                    </button>
                    <button 
                      onClick={() => { setCurrentSection('community'); setIsSidebarOpen(false); }}
                      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left font-semibold ${
                        currentSection === 'community' ? 'bg-indigo-600 text-white' : 'text-slate-350 hover:bg-slate-800'
                      }`}
                    >
                      <Users className="w-5 h-5" /> Communauté & Clubs
                    </button>
                    <button 
                      onClick={() => { setCurrentSection('challenges'); setIsSidebarOpen(false); }}
                      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left font-semibold ${
                        currentSection === 'challenges' ? 'bg-indigo-600 text-white' : 'text-slate-350 hover:bg-slate-800'
                      }`}
                    >
                      <Target className="w-5 h-5" /> Défis & Badges
                    </button>
                    <button 
                      onClick={() => { setCurrentSection('test'); setIsSidebarOpen(false); }}
                      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left font-semibold ${
                        currentSection === 'test' ? 'bg-indigo-600 text-white' : 'text-slate-355 hover:bg-slate-800'
                      }`}
                    >
                      <Award className="w-5 h-5" /> Évaluations & Examens
                    </button>
                    <button 
                      onClick={() => { setCurrentSection('stats'); setIsSidebarOpen(false); }}
                      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left font-semibold ${
                        currentSection === 'stats' ? 'bg-indigo-600 text-white' : 'text-slate-355 hover:bg-slate-800'
                      }`}
                    >
                      <BarChart3 className="w-5 h-5" /> Rapports & Certificat
                    </button>
                  </nav>
                </div>

                <div className="p-4 border-t border-slate-800">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center font-bold">{userName.charAt(0)}</div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold truncate">{userName}</p>
                      <p className="text-xs text-indigo-400">Niveau: {stats.level}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* CONTENT PANEL CENTER */}
          <div className="flex-1 flex flex-col min-w-0">
            
            {/* TOP PREMIUM NAVIGATION BAR */}
            <header className="bg-white border-b border-slate-100 px-6 py-4 flex items-center justify-between shadow-sm sticky top-0 z-40">
              
              {/* Trigger Mobile Sidebar */}
              <div className="flex items-center gap-3 md:gap-0">
                <button 
                  onClick={() => setIsSidebarOpen(true)}
                  className="p-2 rounded-lg bg-slate-100 text-slate-850 md:hidden"
                >
                  <Menu className="w-5 h-5" />
                </button>
                <div className="flex md:hidden items-center gap-2">
                  <span className="font-display font-extrabold text-slate-900 tracking-tight text-lg">GLOIRElingua</span>
                </div>
              </div>

              {/* Status Pills */}
              <div className="hidden md:flex items-center gap-4">
                <div className="flex items-center gap-2 px-3 py-1.5 bg-indigo-50 border border-indigo-100 rounded-full">
                  <GraduationCap className="w-4 h-4 text-indigo-600" />
                  <span className="text-xs font-bold text-indigo-700 uppercase tracking-wide">
                    {stats.level} Mode
                  </span>
                </div>
                
                <div className="flex items-center gap-1 text-slate-605">
                  <Trophy className="w-4.5 h-4.5 text-amber-500" />
                  <span className="text-sm font-bold font-mono">{stats.score} <span className="text-xs text-slate-500 font-sans">XP</span></span>
                </div>

                <div className="flex items-center gap-1.5 text-slate-605">
                  <Zap className="w-4.5 h-4.5 text-orange-500 animate-pulse" />
                  <span className="text-sm font-bold font-mono">{stats.attendanceStreak} jours <span className="text-xs text-slate-500 font-sans">Série</span></span>
                </div>
              </div>

              {/* Action Buttons Right (Notifications + Profile dropdown) */}
              <div className="flex items-center gap-3">
                {/* Notifications Center */}
                <div className="relative">
                  <button 
                    onClick={() => setShowNotificationsDropdown(!showNotificationsDropdown)}
                    className="p-2 hover:bg-slate-50 text-slate-500 hover:text-slate-850 rounded-xl transition relative"
                  >
                    <Bell className="w-5 h-5" />
                    {notifications.some(n => !n.read) && (
                      <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full ring-2 ring-white"></span>
                    )}
                  </button>

                  {/* Dropdown panel */}
                  {showNotificationsDropdown && (
                    <div className="absolute right-0 mt-3 w-80 bg-white border border-slate-100 hover:border-slate-200 shadow-xl rounded-2xl p-4 z-50 animate-fade-in text-left">
                      <div className="flex justify-between items-center border-b border-slate-105 pb-2 mb-3">
                        <span className="font-display font-bold text-sm text-slate-750">Notifications Reculées</span>
                        <button 
                          onClick={() => setNotifications(prev => prev.map(n => ({ ...n, read: true })))}
                          className="text-xs text-indigo-600 hover:underline font-medium"
                        >
                          Tout marquer lu
                        </button>
                      </div>
                      
                      <div className="space-y-3 max-h-64 overflow-y-auto">
                        {notifications.map((notif) => (
                          <div key={notif.id} className={`p-2 rounded-lg text-xs leading-relaxed ${notif.read ? 'bg-slate-50/50' : 'bg-indigo-50/40 border border-indigo-100/30'}`}>
                            <div className="flex justify-between items-center mb-0.5">
                              <span className="font-bold text-slate-800">{notif.title}</span>
                              {!notif.read && <span className="w-1.5 h-1.5 bg-indigo-600 rounded-full"></span>}
                            </div>
                            <p className="text-slate-500">{notif.message}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Profile Circle with custom action */}
                <div className="flex items-center gap-2 pl-3 border-l border-slate-100">
                  <div className="w-8 h-8 rounded-full bg-slate-900 text-indigo-400 font-bold border border-slate-800 flex items-center justify-center text-xs">
                    {userName.charAt(0).toUpperCase()}
                  </div>
                  <span className="text-sm font-semibold hidden sm:inline-block text-slate-700">{userName}</span>
                </div>
              </div>
            </header>

            {/* DYNAMIC MIDDLEWARE CANVAS ROUTING SECTION */}
            <main className="flex-1 p-6 overflow-y-auto">
              
              {/* SECTION: ACADEMIC DASHBOARD */}
              {currentSection === 'dashboard' && (
                <div className="space-y-8">
                  {/* Top Welcome Banner card */}
                  <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-6 md:p-8 text-white relative overflow-hidden shadow-md">
                    <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(99,102,241,0.15),transparent)]"></div>
                    <div className="relative z-10 max-w-xl">
                      <span className="text-xs font-bold uppercase tracking-widest text-indigo-305 bg-indigo-400/10 border border-indigo-400/20 px-3 py-1 rounded-full">
                        Académie linguistique GLOIRElingua
                      </span>
                      <h1 className="text-3xl md:text-4xl font-display font-extrabold tracking-tight mt-4">
                        Welcome back, {userName}!
                      </h1>
                      <p className="text-slate-350 text-sm md:text-base mt-2 leading-relaxed">
                        Pratiquez avec notre assistant tuteur IA ou communiquez avec d'autres apprenants en temps réel. Complétez vos questionnaires interactifs pour monter en grade !
                      </p>
                      
                      {/* Evolutionary Rank status bar */}
                      <div className="mt-6 bg-white/5 border border-white/10 p-4 rounded-2xl">
                        <div className="flex justify-between text-xs font-bold font-mono tracking-wide text-indigo-200 mb-1.5">
                          <span>EXPÉRIENCE GLOBALE</span>
                          <span>{getProgressPercentage()}% vers Grade Supérieur</span>
                        </div>
                        <div className="w-full bg-white/10 h-2.5 rounded-full overflow-hidden">
                          <div className="bg-indigo-500 h-full transition-all duration-300" style={{ width: `${getProgressPercentage()}%` }}></div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Main Dash components */}
                  <Dashboard stats={stats} onUpdateStats={setStats} />
                </div>
              )}

              {/* SECTION: AI PERSONAL TUTOR */}
              {currentSection === 'ai' && (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start h-full">
                  
                  {/* Left Column: Gemini-driven chat simulator */}
                  <div className="lg:col-span-8 bg-white border border-slate-100 rounded-3xl p-5 shadow-sm hover:shadow-md transition duration-350 flex flex-col h-[650px]">
                    <div className="flex justify-between items-center border-b border-slate-100 pb-4 mb-4">
                      <div className="flex items-center gap-2">
                        <div className="w-9 h-9 rounded-lg bg-indigo-100 text-indigo-650 flex items-center justify-center">
                          <Sparkles className="w-5 h-5 animate-pulse" />
                        </div>
                        <div>
                          <h2 className="font-display font-bold text-slate-800">Tuteur IA Conversationnel</h2>
                          <p className="text-xs text-slate-400">Propulsé par la technologie Gemini 3.5-flash</p>
                        </div>
                      </div>
                      
                      {/* Active level label */}
                      <span className="text-xs font-semibold text-indigo-600 bg-indigo-50 px-2.5 py-0.5 rounded-full">
                        Tuteur adapté : {stats.level}
                      </span>
                    </div>

                    {/* Chat Messages container */}
                    <div className="flex-1 overflow-y-auto space-y-4 mb-4 pr-1 scroll-smooth">
                      {aiChatMessages.map((msg, i) => (
                        <div 
                          key={i} 
                          className={`flex gap-3 max-w-[85%] ${
                            msg.role === 'user' ? 'ml-auto flex-row-reverse' : ''
                          }`}
                        >
                          {/* Avatar */}
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs shrink-0 select-none ${
                            msg.role === 'user' ? 'bg-indigo-600 text-white' : 'bg-slate-900 text-indigo-300'
                          }`}>
                            {msg.role === 'user' ? userName.charAt(0) : '🤖'}
                          </div>

                          {/* Message bubble */}
                          <div className={`p-4 rounded-2xl text-sm leading-relaxed whitespace-pre-wrap shadow-sm border ${
                            msg.role === 'user' 
                              ? 'bg-slate-900 border-slate-900 text-white rounded-tr-none' 
                              : 'bg-slate-50 border-slate-100 text-slate-750 rounded-tl-none'
                          }`}>
                            {msg.content}
                          </div>
                        </div>
                      ))}

                      {/* Typing indicator inside our clean loop */}
                      {aiLoading && (
                        <div className="flex gap-3 max-w-[80%]">
                          <div className="w-8 h-8 rounded-full bg-slate-900 text-indigo-300 flex items-center justify-center font-bold text-xs shrink-0 font-display">
                            🤖
                          </div>
                          <div className="bg-slate-50 border border-slate-100 text-slate-500 p-4 rounded-2xl rounded-tl-none text-xs flex items-center gap-2">
                            <span className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"></span>
                            <span className="w-2 h-2 bg-slate-400 rounded-full animate-bounce delay-100"></span>
                            <span className="w-2 h-2 bg-slate-400 rounded-full animate-bounce delay-200"></span>
                            Le tuteur GLOIRElingua réfléchit...
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Prompts accelerators */}
                    {aiChatMessages.length < 3 && (
                      <div className="mb-3">
                        <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1.5">Sujets suggérés :</p>
                        <div className="flex flex-wrap gap-2">
                          <button 
                            onClick={() => setAiInputValue("Je n'ai pas compris la nuance entre le Present Perfect et le Past Simple, explique-moi.")}
                            className="text-xs bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-1.5 rounded-xl border border-slate-150 font-medium transition text-left"
                          >
                            💡 Différence Present Perfect vs Past Simple
                          </button>
                          <button 
                            onClick={() => setAiInputValue("Comment corriger la phrase de réunion : 'We will focus our resources in leverages results' ?")}
                            className="text-xs bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-1.5 rounded-xl border border-slate-150 font-medium transition text-left"
                          >
                            🔍 Corriger phrase de réunion
                          </button>
                          <button 
                            onClick={() => setAiInputValue("Explique-moi l'expression idiomatique américaine 'To take it with a grain of salt'.")}
                            className="text-xs bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-1.5 rounded-xl border border-slate-150 font-medium transition text-left"
                          >
                            🌍 Expressions idiomatiques US
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Chat Text Input */}
                    <div className="flex gap-2 border-t border-slate-100 pt-3">
                      <input 
                        type="text" 
                        placeholder="Posez une question, écrivez une phrase ou demandez une traduction..." 
                        value={aiInputValue}
                        onChange={(e) => setAiInputValue(e.target.value)}
                        onKeyDown={(e) => { if (e.key === 'Enter') sendAiMessage(); }}
                        className="flex-1 p-3 px-4 bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded-xl text-sm focus:outline-none focus:ring-1 focus:ring-indigo-100 font-medium"
                      />
                      <button 
                        onClick={sendAiMessage}
                        disabled={!aiInputValue.trim() || aiLoading}
                        className="p-3 bg-indigo-650 hover:bg-indigo-700 disabled:opacity-45 text-white rounded-xl transition shadow flex items-center justify-center cursor-pointer font-bold"
                      >
                        <Send className="w-5 h-5" />
                      </button>
                    </div>
                  </div>

                  {/* Right Column: Dynamic Text analysis proofreader widget */}
                  <div className="lg:col-span-4 space-y-6">
                    <div className="bg-white border border-slate-100 rounded-3xl p-5 shadow-sm">
                      <div className="flex items-center gap-2 border-b border-slate-100 pb-3 mb-4">
                        <GraduationCap className="w-5 h-5 text-indigo-500" />
                        <h3 className="font-display font-bold text-slate-800">Scrutateur & Correcteur</h3>
                      </div>
                      
                      <p className="text-xs text-slate-500 mb-3 leading-relaxed">
                        Collez un e-mail professionnel, un résumé académique ou une phrase anglaise douteuse ci-dessous pour obtenir une correction rigoureuse.
                      </p>

                      <textarea 
                        rows={4}
                        placeholder="Exemple : She is very good speaker but she have some error on her speech..."
                        value={textToCorrect}
                        onChange={(e) => setTextToCorrect(e.target.value)}
                        className="w-full text-sm p-4 bg-slate-50 border border-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-100 rounded-xl focus:outline-none placeholder-slate-400 font-sans leading-relaxed"
                      />

                      <button 
                        onClick={handleCorrectText}
                        disabled={!textToCorrect.trim() || correctionLoading}
                        className="w-full py-2.5 mt-3 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition cursor-pointer flex items-center justify-center gap-1"
                      >
                        {correctionLoading ? "Analyse en cours..." : "Lancer la correction IA"}
                      </button>

                      {/* Display analysis feedback */}
                      {correctionAnalysis && (
                        <div className="mt-4 p-4 border border-indigo-100 bg-indigo-50/30 rounded-2xl text-xs max-h-64 overflow-y-auto animate-fade-in text-slate-755 leading-relaxed">
                          <p className="font-bold text-indigo-600 mb-1.5 uppercase tracking-wider">Résultats d'analyse GLOIRElingua :</p>
                          <div className="whitespace-pre-wrap font-sans font-medium">{correctionAnalysis}</div>
                        </div>
                      )}
                    </div>

                    {/* Companion notice */}
                    <div className="bg-slate-900 text-slate-350 p-5 rounded-3xl border border-white/5 space-y-3">
                      <h4 className="font-display text-white text-xs font-bold uppercase tracking-widest flex items-center gap-1.5">
                        <Shield className="w-4 h-4 text-emerald-400" /> Sécurité des données
                      </h4>
                      <p className="text-xs leading-relaxed">
                        Toutes les analyses et corrections de textes ou d'audio sont traitées côté serveur de manière anonyme et sécurisée.
                      </p>
                    </div>
                  </div>

                </div>
              )}

              {/* SECTION: COMMUNITY & SOCIAL LOUNGE */}
              {currentSection === 'community' && (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch h-full">
                  
                  {/* Left Column: Active learner directory */}
                  <div className="lg:col-span-4 bg-white border border-slate-100 rounded-3xl p-5 shadow-sm flex flex-col h-[650px]">
                    <div className="border-b border-slate-100 pb-4 mb-4 space-y-3">
                      <div className="flex items-center gap-2">
                        <Users className="w-5 h-5 text-indigo-600" />
                        <h2 className="font-display font-bold text-slate-800">Partenaires d'anglais</h2>
                      </div>

                      {/* Search Bar */}
                      <div className="relative">
                        <Search className="w-4 h-4 text-slate-400 absolute top-3.5 left-3.5" />
                        <input 
                          type="text" 
                          placeholder="Rechercher par nom, pays, intérêt..." 
                          value={communitySearch}
                          onChange={(e) => setCommunitySearch(e.target.value)}
                          className="w-full text-xs p-3 pl-10 bg-slate-50 border border-slate-205 focus:border-indigo-500 focus:outline-none rounded-xl"
                        />
                      </div>

                      {/* Sorting levels filter */}
                      <div className="flex gap-1.5 overflow-x-auto pb-1">
                        {['all', 'beginner', 'advanced', 'professional'].map((lbl) => (
                          <button
                            key={lbl} 
                            onClick={() => setFilterLevel(lbl)}
                            className={`text-2xs font-semibold px-2.5 py-1 rounded-full border transition whitespace-nowrap ${
                              filterLevel === lbl 
                                ? 'bg-indigo-600 text-white border-indigo-650' 
                                : 'bg-slate-100 hover:bg-slate-150 text-slate-600 border-slate-150'
                            }`}
                          >
                            {lbl === 'all' ? 'Tous' : lbl.toUpperCase()}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Social List */}
                    <div className="flex-1 overflow-y-auto space-y-2 pr-1">
                      {filteredFriends.map((person) => (
                        <button
                          key={person.id}
                          onClick={() => setSelectedFriend(person)}
                          className={`w-full p-3 rounded-2xl flex items-center justify-between border text-left transition ${
                            selectedFriend?.id === person.id 
                              ? 'bg-slate-900 text-white border-slate-900 shadow-sm' 
                              : 'bg-white hover:bg-slate-50 border-slate-100 text-slate-800'
                          }`}
                        >
                          <div className="flex items-center gap-3 min-w-0">
                            {/* Avatar */}
                            <div className="relative shrink-0">
                              <img src={person.avatar} alt={person.name} className="w-10 h-10 rounded-full object-cover border border-slate-200" />
                              <span className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full ring-2 ring-white ${person.isOnline ? 'bg-emerald-500' : 'bg-slate-400'}`}></span>
                            </div>
                            
                            {/* Meta */}
                            <div className="min-w-0">
                              <p className="font-bold text-xs truncate flex items-center gap-1.5">
                                {person.name} <span>{person.flag}</span>
                              </p>
                              <p className="text-2xs opacity-80 mt-0.5 truncate uppercase font-bold tracking-wider">{person.level} • {person.country}</p>
                            </div>
                          </div>

                          <span className="text-2xs font-bold font-mono px-2 py-0.5 bg-slate-105 border border-slate-150 rounded-full text-slate-600">
                            {person.score} XP
                          </span>
                        </button>
                      ))}

                      {filteredFriends.length === 0 && (
                        <p className="text-center text-xs text-slate-400 mt-20">Aucun apprenant trouvé pour vos critères.</p>
                      )}
                    </div>
                  </div>

                  {/* Right Column: Chat screen console */}
                  <div className="lg:col-span-8 bg-white border border-slate-100 rounded-3xl p-5 shadow-sm flex flex-col h-[650px]">
                    {selectedFriend ? (
                      <div className="flex-1 flex flex-col justify-between">
                        
                        {/* Companion header widget */}
                        <div className="flex justify-between items-center border-b border-slate-100 pb-3 mb-4">
                          <div className="flex items-center gap-3">
                            <img src={selectedFriend.avatar} alt={selectedFriend.name} className="w-10 h-10 rounded-full object-cover border" />
                            <div>
                              <h3 className="font-display font-bold text-sm text-slate-805 flex items-center gap-1.5">
                                {selectedFriend.name} <span>{selectedFriend.flag}</span>
                              </h3>
                              <p className="text-2xs font-semibold text-slate-400">
                                Intérêts : {selectedFriend.interests.join(', ')}
                              </p>
                            </div>
                          </div>

                          {/* Quick Audio & Video Call buttons */}
                          <div className="flex gap-2">
                            <button 
                              onClick={() => triggerCall('voice', selectedFriend)}
                              className="p-2 sm:px-3 sm:py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-semibold text-xs rounded-xl flex items-center gap-1 transition"
                              title="Déclencher un appel vocal interactif"
                            >
                              <Phone className="w-4 h-4" /> <span className="hidden sm:inline">Appel Vocal</span>
                            </button>
                            <button 
                              onClick={() => triggerCall('video', selectedFriend)}
                              className="p-2 sm:px-3 sm:py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-semibold text-xs rounded-xl flex items-center gap-1 transition"
                              title="Déclencher un appel vidéo interactif"
                            >
                              <Video className="w-4 h-4" /> <span className="hidden sm:inline">Appel Vidéo</span>
                            </button>
                          </div>
                        </div>

                        {/* Social Messages feed */}
                        <div className="flex-1 overflow-y-auto space-y-4 mb-4 pr-1">
                          {(directMessages[selectedFriend.id] || []).map((msg) => {
                            const isMe = msg.senderId === 'user';
                            return (
                              <div key={msg.id} className={`flex gap-3 max-w-[80%] ${isMe ? 'ml-auto flex-row-reverse' : ''}`}>
                                <img src={msg.senderAvatar} alt={msg.senderName} className="w-8 h-8 rounded-full object-cover border" />
                                <div>
                                  <div className={`p-4 rounded-2xl text-xs leading-relaxed border ${
                                    isMe 
                                      ? 'bg-slate-900 text-white border-slate-900 rounded-tr-none' 
                                      : 'bg-slate-50 border-slate-100 text-slate-750 rounded-tl-none'
                                  }`}>
                                    {msg.text}

                                    {/* Simulated File attachment inside feed */}
                                    {msg.fileName && (
                                      <div className={`mt-2 p-2.5 rounded-lg flex items-center gap-2 border text-xs ${
                                        isMe ? 'bg-white/10 border-white/15 text-white' : 'bg-indigo-50 border-indigo-150 text-indigo-850'
                                      }`}>
                                        <FileText className="w-4 h-4" />
                                        <div>
                                          <p className="font-bold">{msg.fileName}</p>
                                          <p className="text-2xs opacity-75">Document de partage de cours</p>
                                        </div>
                                      </div>
                                    )}
                                  </div>
                                  <p className={`text-3xs text-slate-400 mt-1 ${isMe ? 'text-right' : ''}`}>{msg.timestamp}</p>
                                </div>
                              </div>
                            );
                          })}
                        </div>

                        {/* File Upload simulator drawer banner */}
                        {attachedFile && (
                          <div className="mb-2 bg-slate-50 border border-slate-200 p-2.5 rounded-xl flex items-center justify-between text-xs animate-fade-in">
                            <div className="flex items-center gap-2 text-slate-650">
                              <FileText className="w-4 h-4 text-indigo-600" />
                              <div>
                                <p className="font-bold">{attachedFile.name}</p>
                                <p className="text-3xs text-slate-450">{attachedFile.size}</p>
                              </div>
                            </div>
                            <button onClick={() => setAttachedFile(null)} className="p-1.5 hover:bg-slate-20 hover:text-red-500 rounded text-slate-400 transition">
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}

                        {/* Group conversation trigger */}
                        <div className="flex gap-2 items-center border-t border-slate-100 pt-3">
                          {/* File Attachment simulation click input */}
                          <label className="p-3 bg-slate-50 border border-slate-250 hover:bg-slate-100 rounded-xl cursor-pointer transition text-slate-500 flex justify-center items-center">
                            <Upload className="w-4.5 h-4.5" />
                            <input 
                              type="file" 
                              onChange={handleChatFileSelect} 
                              className="hidden" 
                              accept=".pdf,.png,.jpg,.jpeg,.doc,.docx,.mp3"
                            />
                          </label>

                          <input 
                            type="text" 
                            placeholder={`Répondre à ${selectedFriend.name} (Pratiquez votre anglais)...`} 
                            value={chatInputValue}
                            onChange={(e) => setChatInputValue(e.target.value)}
                            onKeyDown={(e) => { if (e.key === 'Enter') handleSendChatMessage(); }}
                            className="flex-1 p-3 bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded-xl text-xs focus:outline-none focus:ring-1 focus:ring-indigo-100 font-medium"
                          />
                          <button 
                            onClick={handleSendChatMessage}
                            disabled={!chatInputValue.trim() && !attachedFile}
                            className="p-3 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-45 text-white rounded-xl transition cursor-pointer flex items-center justify-center font-bold"
                          >
                            <Send className="w-4.5 h-4.5" />
                          </button>
                        </div>

                      </div>
                    ) : (
                      <div className="flex-1 flex flex-col items-center justify-center text-center p-6 text-slate-400">
                        <Users className="w-12 h-12 text-slate-300 animate-bounce mb-3" />
                        <h4 className="font-display font-medium text-slate-700">Aucun interlocuteur actif</h4>
                        <p className="text-xs max-w-sm mx-auto mt-1 leading-relaxed">
                          Sélectionnez l'un de vos correspondants d'apprentissage dans l'annuaire de gauche pour débuter un dialogue ou lancer un appel vocal/vidéo !
                        </p>
                      </div>
                    )}
                  </div>

                </div>
              )}

              {/* SECTION: SKILL CHALLENGES (MINI TESTS) */}
              {currentSection === 'challenges' && (
                <div className="space-y-8 max-w-5xl mx-auto">
                  <div className="flex justify-between items-center flex-col sm:flex-row gap-4 border-b border-slate-100 pb-5">
                    <div>
                      <h2 className="text-2xl font-display text-slate-800 font-bold">Défis & Distinctions Académiques</h2>
                      <p className="text-slate-500 text-sm mt-1">Relevez de petits défis interactifs de vocabulaire ou de grammaire, gagnez des points XP et arborez de prestigieux badges d'apprentissage.</p>
                    </div>

                    <div className="flex items-center gap-2 bg-indigo-50 text-indigo-700 border border-indigo-100 p-2.5 rounded-xl text-xs font-bold leading-none">
                      <Trophy className="w-5 h-5 animate-bounce" />
                      <div>
                        <p className="text-[10px] uppercase text-indigo-500 tracking-wide">TOTAL BADGES UNLOCKED</p>
                        <p className="text-lg font-mono font-extrabold mt-0.5">{stats.badges.length}</p>
                      </div>
                    </div>
                  </div>

                  {/* Active Gameplay block if minigame has been triggered */}
                  {miniGameActive && (
                    <div className="bg-slate-900 text-white rounded-3xl p-6 md:p-8 animate-fade-in border border-indigo-500/25 relative overflow-hidden">
                      <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_right,rgba(99,102,241,0.08),transparent)]"></div>
                      <div className="relative z-10 max-w-2xl mx-auto">
                        <div className="flex justify-between items-center text-xs font-semibold uppercase tracking-wider text-indigo-400 mb-2">
                          <span>Défi Vocabulaire Actif (Speed Match)</span>
                          <span>Mot {miniGameStep + 1} de {miniGameWords.length}</span>
                        </div>
                        
                        <div className="w-full bg-white/10 h-1.5 rounded-full mb-6 overflow-hidden">
                          <div 
                            className="bg-indigo-500 h-full transition-all duration-300"
                            style={{ width: `${((miniGameStep + 1) / miniGameWords.length) * 100}%` }}
                          ></div>
                        </div>

                        {/* Gameplay question */}
                        <div className="text-center py-6">
                          <p className="text-3s font-mono uppercase text-indigo-305 tracking-widest font-bold">Que signifie le mot / expression :</p>
                          <h3 className="text-4xl font-display font-extrabold tracking-tight text-white mt-1.5">{miniGameWords[miniGameStep].word}</h3>
                        </div>

                        {/* Select Option */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 mt-4">
                          {miniGameWords[miniGameStep].options.map((opt, optionId) => (
                            <button
                              key={optionId}
                              onClick={() => handleMiniGameAnswer(optionId)}
                              className="p-4 rounded-xl border border-white/10 hover:border-indigo-400 hover:bg-indigo-500/10 text-left text-sm font-semibold transition cursor-pointer text-slate-205"
                            >
                              {optionId + 1}. {opt}
                            </button>
                          ))}
                        </div>
                        
                        <div className="flex justify-end mt-6">
                          <button 
                            onClick={() => setMiniGameActive(false)}
                            className="text-xs text-slate-500 hover:text-slate-300 font-semibold"
                          >
                            Annuler et abandonner le défi
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* List of general Challenges cards */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {challenges.map((ch) => (
                      <div 
                        key={ch.id} 
                        className={`bg-white border rounded-3xl p-6 relative overflow-hidden flex flex-col justify-between h-[230px] shadow-sm transition hover:shadow-md ${
                          ch.completed ? 'border-emerald-100 bg-emerald-50/5' : 'border-slate-100'
                        }`}
                      >
                        <div>
                          <div className="flex justify-between items-start mb-4">
                            <span className="text-[10px] font-bold uppercase tracking-widest px-2.5 py-1 rounded-full border bg-slate-50 text-slate-650">
                              Module : {ch.type}
                            </span>
                            
                            {ch.completed ? (
                              <span className="text-xs font-bold text-emerald-600 bg-emerald-50 border border-emerald-100 px-3 py-1 rounded-full flex items-center gap-1">
                                <Check className="w-3.5 h-3.5" /> Complété (+{ch.points} XP)
                              </span>
                            ) : (
                              <span className="text-xs font-bold font-mono text-indigo-700 bg-indigo-50 border border-indigo-100 px-3 py-0.5 rounded-full">
                                +{ch.points} XP
                              </span>
                            )}
                          </div>

                          <h3 className="font-display font-bold text-slate-800 text-lg">{ch.title}</h3>
                          <p className="text-slate-500 text-xs mt-2 leading-relaxed line-clamp-2">{ch.description}</p>
                        </div>

                        <div className="flex items-center justify-between border-t border-slate-100 pt-4 mt-4">
                          <span className="text-xs font-bold text-slate-705 flex items-center gap-1">
                            Récompense Badge : <span className="p-1 px-2.5 rounded-lg bg-yellow-50 text-yellow-700 font-semibold border border-yellow-101 shrink-0">{ch.badge}</span>
                          </span>

                          {ch.id === 'ch1' && !ch.completed && !miniGameActive && (
                            <button
                              onClick={() => { setMiniGameActive(true); setMiniGameStep(0); setMiniGameScore(0); }}
                              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition shadow cursor-pointer flex items-center gap-1"
                            >
                              <Play className="w-4 h-4 fill-current" /> Démarrer le défi
                            </button>
                          )}
                          {ch.id !== 'ch1' && !ch.completed && (
                            <button
                              disabled
                              className="px-4 py-2 bg-slate-100 text-slate-400 rounded-xl text-2xs font-semibold cursor-not-allowed"
                            >
                              Sujet verrouillé
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Leaderboard and local high-achievers ranking row */}
                  <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-sm">
                    <h3 className="font-display font-bold text-slate-808 flex items-center gap-2 mb-4">
                      <Trophy className="w-5 h-5 text-amber-500" /> Classement de votre promotion GLOIRElingua
                    </h3>
                    
                    <div className="space-y-3">
                      {/* Self */}
                      <div className="p-3 bg-indigo-50/50 rounded-2xl flex items-center justify-between border border-indigo-100">
                        <div className="flex items-center gap-3">
                          <span className="font-mono font-bold text-indigo-700 text-sm">#1</span>
                          <div className="w-8 h-8 rounded-full bg-slate-900 border text-indigo-400 font-bold text-xs flex items-center justify-center">
                            {userName.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <p className="font-bold text-xs text-slate-800">{userName} <span className="text-3s font-bold text-indigo-600 border border-indigo-100 px-1 py-0.5 rounded ml-1 bg-white uppercase">Vous</span></p>
                            <p className="text-[10px] text-slate-400 uppercase tracking-widest">{stats.level} Level</p>
                          </div>
                        </div>
                        <span className="font-mono font-bold text-indigo-700 text-sm">{stats.score} XP</span>
                      </div>

                      {/* Rank 2 */}
                      <div className="p-3 bg-white hover:bg-slate-50/50 rounded-2xl flex items-center justify-between border border-slate-100 transition duration-200">
                        <div className="flex items-center gap-3">
                          <span className="font-mono font-bold text-slate-400 text-sm">#2</span>
                          <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150" className="w-8 h-8 rounded-full object-cover" alt="Sofia" />
                          <div>
                            <p className="font-bold text-xs text-slate-800">Sofia Alvarez 🇪🇸</p>
                            <p className="text-[10px] text-slate-400 uppercase tracking-widest">Professional Level</p>
                          </div>
                        </div>
                        <span className="font-mono font-semibold text-slate-600 text-sm">3400 XP</span>
                      </div>

                      {/* Rank 3 */}
                      <div className="p-3 bg-white hover:bg-slate-50/50 rounded-2xl flex items-center justify-between border border-slate-100 transition duration-200">
                        <div className="flex items-center gap-3">
                          <span className="font-mono font-bold text-slate-400 text-sm">#3</span>
                          <img src="https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=150" className="w-8 h-8 rounded-full object-cover" alt="Amara" />
                          <div>
                            <p className="font-bold text-xs text-slate-800">Amara Diop 🇸🇳</p>
                            <p className="text-[10px] text-slate-400 uppercase tracking-widest">Advanced Level</p>
                          </div>
                        </div>
                        <span className="font-mono font-semibold text-slate-600 text-sm">1850 XP</span>
                      </div>

                    </div>
                  </div>

                </div>
              )}

              {/* SECTION: SKILL TESTS & ASSESSMENTS */}
              {currentSection === 'test' && (
                <div className="max-w-4xl mx-auto space-y-8">
                  
                  {/* Top info card */}
                  <div className="bg-gradient-to-tr from-indigo-900 to-indigo-800 text-white rounded-3xl p-6 md:p-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-6 shadow-md relative overflow-hidden">
                    <div className="space-y-2 relative z-10">
                      <span className="text-xs font-bold text-indigo-200 bg-white/10 px-3 py-1 rounded-full border border-white/10">
                        Alignement IELTS / TOEFL International
                      </span>
                      <h2 className="text-2xl md:text-3xl font-display font-extrabold tracking-tight">Vérifiez vos acquis réels</h2>
                      <p className="text-slate-300 text-xs md:text-sm max-w-md leading-relaxed">
                        Passez un test global évaluant la compréhension orale et écrite, l'orthographe complexe, la grammaire et la synthèse pour re-calculer votre niveau GLOIRElingua homologué.
                      </p>
                    </div>

                    {!testActive && (
                      <button 
                        onClick={() => { setTestActive(true); setTestStep(0); setTestAnswers({}); }}
                        className="px-6 py-3 bg-white text-indigo-700 hover:bg-indigo-50 font-bold text-sm rounded-2xl transition shadow cursor-pointer text-center whitespace-nowrap"
                      >
                        Lancer l'évaluation globale (+500 XP)
                      </button>
                    )}
                  </div>

                  {/* ACTIVE EXAM CONTAINER WIDGET */}
                  {testActive && (
                    <div className="bg-white border border-indigo-150 rounded-3xl p-6 md:p-8 shadow-md relative animate-fade-in">
                      
                      {/* Step Header */}
                      <div className="flex justify-between items-center text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                        <span>Compétence {testStep + 1} de {ASSESSMENT_QUESTIONS.length}</span>
                        <span className="text-indigo-650 bg-indigo-50 px-2 rounded-full border border-indigo-100">
                          {ASSESSMENT_QUESTIONS[testStep].context}
                        </span>
                      </div>

                      {/* Bar indicator */}
                      <div className="w-full bg-slate-100 h-2 mb-6 rounded-full overflow-hidden">
                        <div 
                          className="bg-indigo-600 h-full transition-all duration-300"
                          style={{ width: `${((testStep + 1) / ASSESSMENT_QUESTIONS.length) * 100}%` }}
                        ></div>
                      </div>

                      {/* Question Content */}
                      <div className="bg-slate-50 border border-slate-100 p-6 rounded-2xl space-y-4 mb-6">
                        <h3 className="font-display font-extrabold text-slate-800 text-base whitespace-pre-line leading-relaxed">
                          {ASSESSMENT_QUESTIONS[testStep].question}
                        </h3>

                        {/* Speech synthesis tool trigger helper for listening part of exam */}
                        {ASSESSMENT_QUESTIONS[testStep].type === 'listening' && (
                          <div className="p-4 bg-orange-50 border border-orange-100 rounded-2xl flex items-center gap-4">
                            <button
                              onClick={() => speakExamSentence(ASSESSMENT_QUESTIONS[testStep].audioText || '')}
                              className="w-12 h-12 rounded-xl bg-orange-500 hover:bg-orange-600 text-white flex items-center justify-center transition active:scale-95 shadow shrink-0"
                            >
                              <Volume2 className="w-5 h-5 animate-pulse" />
                            </button>
                            <div>
                              <p className="text-xs font-bold text-orange-700 uppercase tracking-widest">Dictée vocale synthétique</p>
                              <p className="text-2xs text-slate-500 mt-0.5">Cliquez pour entendre la voix synthétique anglaise et tapez exactement ce que vous entendez.</p>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Responses widget type match */}
                      {ASSESSMENT_QUESTIONS[testStep].type === 'multiple' && (
                        <div className="space-y-2.5 mb-6">
                          {ASSESSMENT_QUESTIONS[testStep].options?.map((opt, i) => (
                            <button
                              key={i}
                              onClick={() => handleTestSelection(ASSESSMENT_QUESTIONS[testStep].id, opt)}
                              className={`w-full text-left p-4 rounded-xl border text-xs font-semibold flex items-center justify-between transition-all ${
                                testAnswers[ASSESSMENT_QUESTIONS[testStep].id] === opt 
                                  ? 'border-indigo-600 bg-indigo-50/50 text-indigo-750' 
                                  : 'border-slate-100 hover:border-slate-200 bg-white'
                              }`}
                            >
                              <span>{opt}</span>
                              <span className="w-4 h-4 rounded-full border border-slate-350 flex items-center justify-center">
                                {testAnswers[ASSESSMENT_QUESTIONS[testStep].id] === opt && <span className="w-2.5 h-2.5 bg-indigo-650 rounded-full"></span>}
                              </span>
                            </button>
                          ))}
                        </div>
                      )}

                      {(ASSESSMENT_QUESTIONS[testStep].type === 'input' || ASSESSMENT_QUESTIONS[testStep].type === 'listening') && (
                        <div className="mb-6">
                          <label className="block text-2xs font-bold uppercase tracking-widest text-slate-400 mb-2">Tapez votre réponse :</label>
                          <input 
                            type="text"
                            placeholder="Ex: writing down here..."
                            value={testAnswers[ASSESSMENT_QUESTIONS[testStep].id] || ''}
                            onChange={(e) => handleTestSelection(ASSESSMENT_QUESTIONS[testStep].id, e.target.value)}
                            className="w-full p-4 rounded-xl border border-slate-205 focus:border-indigo-500 focus:outline-none font-sans font-medium"
                          />
                        </div>
                      )}

                      {/* Actions */}
                      <div className="flex justify-between items-center border-t border-slate-100 pt-5">
                        <button
                          onClick={() => setTestStep(prev => Math.max(0, prev - 1))}
                          disabled={testStep === 0}
                          className="px-4 py-2 border border-slate-200 text-slate-500 text-xs font-semibold hover:bg-slate-50 disabled:opacity-40 rounded-xl"
                        >
                          Précédent
                        </button>

                        {testStep < ASSESSMENT_QUESTIONS.length - 1 ? (
                          <button
                            onClick={() => setTestStep(prev => prev + 1)}
                            disabled={!testAnswers[ASSESSMENT_QUESTIONS[testStep].id]}
                            className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-white font-bold text-xs rounded-xl transition cursor-pointer"
                          >
                            Suivant
                          </button>
                        ) : (
                          <button
                            onClick={submitFinalAssessment}
                            className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow cursor-pointer animate-pulse"
                          >
                            Calculer mon verdict linguistique
                          </button>
                        )}
                      </div>

                    </div>
                  )}

                  {/* DISPLAY HISTORICAL ATTEMPTS RESULTS & ANALYTICAL GRAPHS */}
                  <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-sm">
                    <h3 className="font-display font-bold text-slate-800 flex items-center gap-2 mb-4">
                      <ListChecks className="w-5 h-5 text-indigo-500" /> Historique de vos diplômes et verdicts d'examens
                    </h3>

                    <div className="space-y-4">
                      {testResults.map((targetRes) => (
                        <div key={targetRes.id} className="p-4 border border-slate-100 rounded-2xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4 hover:border-slate-150 transition">
                          <div>
                            <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                              <span className="text-2xs font-bold text-indigo-700 bg-indigo-50 border border-indigo-100 px-2 py-0.5 rounded">
                                Verdict du {targetRes.date}
                              </span>
                              <span className="text-3s font-bold text-emerald-600 bg-emerald-50 border border-emerald-100 uppercase tracking-widest px-2 py-0.5 rounded">
                                SCORE : {targetRes.score}/100
                              </span>
                            </div>
                            <h4 className="font-display font-bold text-sm text-slate-800">Assignation : Niveau {targetRes.estimatedLevel.toUpperCase()}</h4>
                            <p className="text-xs text-slate-500 mt-1 leading-relaxed max-w-xl">{targetRes.analysis}</p>
                          </div>

                          <button
                            onClick={() => { setViewingResult(targetRes); setCurrentSection('stats'); }}
                            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-bold rounded-lg transition whitespace-nowrap self-stretch md:self-center text-center"
                          >
                            Voir Diagnostic Complet
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>

                </div>
              )}

              {/* SECTION: STATS, PROGRESS & DIPLOMAS REPORT CARD */}
              {currentSection === 'stats' && (
                <div className="max-w-4xl mx-auto space-y-8">
                  <div className="flex justify-between items-center border-b border-slate-100 pb-5">
                    <div>
                      <h2 className="text-2xl font-display text-slate-800 font-bold">Rapports d'Acquis & Diplômes</h2>
                      <p className="text-slate-500 text-sm mt-1">Consultez vos statistiques personnelles consolidées ou éditez votre certificat de compétences GLOIRElingua.</p>
                    </div>
                  </div>

                  {/* STATS COUNT GRID */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="bg-white border border-slate-100 p-5 rounded-3xl shadow-3xs">
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">XP Cumulés</p>
                      <p className="text-2xl font-display font-extrabold text-indigo-700 font-mono tracking-tight">{stats.score}</p>
                    </div>

                    <div className="bg-white border border-slate-100 p-5 rounded-3xl shadow-3xs">
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Mots Maîtrisés</p>
                      <p className="text-2xl font-display font-extrabold text-emerald-600 font-mono tracking-tight">{stats.vocabularyMasteredCount}</p>
                    </div>

                    <div className="bg-white border border-slate-100 p-5 rounded-3xl shadow-3xs">
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Examens Réussis</p>
                      <p className="text-2xl font-display font-extrabold text-indigo-600 font-mono tracking-tight">{stats.testsCompletedCount}</p>
                    </div>

                    <div className="bg-white border border-slate-100 p-5 rounded-3xl shadow-3xs">
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Temps Appris</p>
                      <p className="text-2xl font-display font-extrabold text-orange-600 font-mono tracking-tight">{stats.learningTimeMinutes} <span className="text-xs font-sans text-slate-400 font-bold">min</span></p>
                    </div>
                  </div>

                  {/* ACTIVE ASSESSMENT RESULT DIAGNOSTICS */}
                  {viewingResult ? (
                    <div className="bg-slate-900 text-white rounded-3xl p-6 md:p-8 border border-slate-800 space-y-6 relative animate-fade-in">
                      <div className="flex justify-between items-start border-b border-slate-800 pb-4 flex-wrap gap-4">
                        <div>
                          <span className="text-3s font-bold text-indigo-300 bg-indigo-500/10 border border-indigo-500/20 px-2.5 py-1 rounded-full uppercase tracking-wider">
                            Rapport linguistique détaillé
                          </span>
                          <h3 className="text-xl font-display font-bold text-white mt-2">Bilan Diagnostics - {viewingResult.date}</h3>
                          <p className="text-xs text-slate-450 mt-1">Évaluation globale IELTS/TOEFL accomplie</p>
                        </div>
                        
                        <div className="bg-white/5 border border-white/10 p-3 rounded-2xl text-center">
                          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Niveau estimé</p>
                          <p className="text-2xl font-display font-extrabold text-indigo-400 uppercase tracking-tight">{viewingResult.estimatedLevel}</p>
                        </div>
                      </div>

                      {/* Skill Meters Bar breakdown */}
                      <div className="space-y-3.5">
                        <h4 className="text-2xs font-bold text-slate-350 uppercase tracking-widest">Compétences par disciplines</h4>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <div className="flex justify-between text-xs font-mono font-bold tracking-wide text-indigo-200 mb-1">
                              <span>Reading (Compréhension écrite)</span>
                              <span>{viewingResult.breakdown.reading}%</span>
                            </div>
                            <div className="w-full bg-white/10 h-2 rounded-full overflow-hidden">
                              <div className="bg-indigo-500 h-full" style={{ width: `${viewingResult.breakdown.reading}%` }}></div>
                            </div>
                          </div>

                          <div>
                            <div className="flex justify-between text-xs font-mono font-bold tracking-wide text-indigo-205 mb-1">
                              <span>Writing (Rédaction et orthographe)</span>
                              <span>{viewingResult.breakdown.writing}%</span>
                            </div>
                            <div className="w-full bg-white/10 h-2 rounded-full overflow-hidden">
                              <div className="bg-indigo-500 h-full" style={{ width: `${viewingResult.breakdown.writing}%` }}></div>
                            </div>
                          </div>

                          <div>
                            <div className="flex justify-between text-xs font-mono font-bold tracking-wide text-indigo-205 mb-1">
                              <span>Listening (Compréhension orale)</span>
                              <span>{viewingResult.breakdown.listening}%</span>
                            </div>
                            <div className="w-full bg-white/10 h-2 rounded-full overflow-hidden">
                              <div className="bg-indigo-505 h-full" style={{ width: `${viewingResult.breakdown.listening}%` }}></div>
                            </div>
                          </div>

                          <div>
                            <div className="flex justify-between text-xs font-mono font-bold tracking-wide text-indigo-205 mb-1">
                              <span>Speaking (Élocution et accentuation)</span>
                              <span>{viewingResult.breakdown.speaking}%</span>
                            </div>
                            <div className="w-full bg-white/10 h-2 rounded-full overflow-hidden">
                              <div className="bg-indigo-505 h-full" style={{ width: `${viewingResult.breakdown.speaking}%` }}></div>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Synthesis */}
                      <div className="bg-white/5 border border-white/10 p-4 rounded-2xl text-xs space-y-1 text-slate-300 leading-relaxed">
                        <p className="font-bold text-slate-100">Analyse globale de votre profil :</p>
                        <p className="italic">"{viewingResult.analysis}"</p>
                      </div>

                      {/* Action back to metrics */}
                      <div className="flex justify-end">
                        <button 
                          onClick={() => setViewingResult(null)}
                          className="text-xs text-indigo-400 hover:text-white hover:underline transition"
                        >
                          Masquer le bilan détaillé
                        </button>
                      </div>
                    </div>
                  ) : null}

                  {/* 3. PRINTABLE OFFICIAL COMPLETION DIPLOMA / CERTIFICATE CARD */}
                  <div className="bg-white border-2 border-dashed border-indigo-200 rounded-3xl p-8 text-center text-slate-800 space-y-6 shadow bg-[radial-gradient(circle_at_center,rgba(99,102,241,0.01),transparent)] relative overflow-hidden">
                    
                    {/* Security stamp watermark */}
                    <div className="absolute -top-12 -right-12 w-48 h-48 bg-indigo-50 rounded-full opacity-45 -z-10 flex items-center justify-center text-indigo-150 transform rotate-12">
                      <GraduationCap className="w-24 h-24" />
                    </div>

                    <div className="max-w-xl mx-auto space-y-4">
                      <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 border border-indigo-150 px-3 py-1 rounded-full uppercase tracking-widest select-none">
                        Diplôme officiel d'excellence GLOIRElingua
                      </span>
                      <h3 className="text-2xl md:text-3xl font-display font-extrabold tracking-tight text-slate-900 uppercase">
                        Certificate of Progression
                      </h3>
                      <p className="text-slate-400 text-xs italic tracking-wider leading-relaxed">
                        Ce certificat atteste officiellement de l'assiduité linguistique et de l'acquisition des compétences anglaises avancées validées par le tuteur IA de l'Académie GLOIRElingua.
                      </p>

                      {/* Certificate Core details */}
                      <div className="my-8 py-6 border-y border-slate-150 space-y-2 relative">
                        <p className="text-slate-400 text-2xs uppercase tracking-widest">Décerné solennellement à</p>
                        <p className="text-2xl font-display font-bold text-slate-900 tracking-tight italic underline decoration-indigo-505 decoration-2 underline-offset-4 uppercase">{userName}</p>
                        
                        <div className="grid grid-cols-2 gap-4 mt-6 text-left max-w-sm mx-auto text-3xs font-mono font-bold tracking-wide uppercase text-slate-450 border-t border-slate-105 pt-4">
                          <div>
                            <p>Niveau Validé : <span className="text-indigo-605">{stats.level.toUpperCase()}</span></p>
                            <p>Points XP : {stats.score}</p>
                          </div>
                          <div className="text-right">
                            <p>Date d'édition : {new Date().toLocaleDateString('fr-FR')}</p>
                            <p>Statut : OFFICIEUX / DIGITAL</p>
                          </div>
                        </div>
                      </div>

                      {/* Download PDF button trigger print */}
                      <button
                        onClick={() => window.print()}
                        className="px-5 py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-2xl transition cursor-pointer flex items-center justify-center gap-1.5 mx-auto shadow-sm"
                      >
                        <Printer className="w-4.5 h-4.5" /> Télécharger mon Certificat (Imprimer PDF)
                      </button>
                    </div>

                  </div>

                </div>
              )}

            </main>
          </div>

          {/* 4. CHIEF OVERLAY SYSTEM: AUDIO & VIDEO MOCK CALL OVERLAY */}
          {activeCall && (
            <div className="fixed inset-0 bg-slate-950/95 z-55 flex flex-col justify-between p-6 text-white text-center select-none animate-fade-in backdrop-blur-sm">
              
              {/* Overlay header */}
              <div className="flex justify-between items-center max-w-4xl mx-auto w-full">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-400 uppercase tracking-widest leading-none text-left">
                  <Shield className="w-4.5 h-4.5 text-indigo-400 shrink-0" />
                  <div>
                    <p>Salon linguistique GLOIRElingua</p>
                    <p className="text-[10px] text-emerald-400 mt-0.5 normal-case">Liaison protégée de bout en bout</p>
                  </div>
                </div>
                
                <span className="text-xs font-bold tracking-wider text-indigo-400 font-mono bg-white/5 border border-white/10 px-3 py-1 rounded-full">
                  {Math.floor(callDuration / 60)}:{(callDuration % 60).toString().padStart(2, '0')}
                </span>
              </div>

              {/* Central Core: Streams & Avatars */}
              <div className="max-w-4xl mx-auto w-full flex-1 flex flex-col md:flex-row items-center justify-center gap-8 py-6">
                
                {/* Local Subscriber Screen Area */}
                <div className="w-full max-w-sm aspect-video bg-slate-950 border border-white/10 rounded-3xl relative overflow-hidden flex flex-col items-center justify-center">
                  {activeCall.type === 'video' && activeCall.streamGranted && !localCamMuted ? (
                    <video 
                      ref={videoRef}
                      className="w-full h-full object-cover transform scale-x-[-1]"
                      muted
                      playsInline
                    />
                  ) : (
                    <div className="text-center space-y-2">
                      <div className="w-16 h-16 rounded-full bg-indigo-600/10 text-indigo-400 border border-indigo-400/20 flex items-center justify-center mx-auto text-xl font-bold font-display uppercase">
                        {userName.charAt(0)}
                      </div>
                      <p className="text-xs font-bold text-slate-450 uppercase tracking-wider">{userName}</p>
                      <p className="text-3xs text-slate-500 italic">Caméra désactivée / Non partagée</p>
                    </div>
                  )}
                  
                  {/* Local overlay flag */}
                  <span className="absolute top-3 left-3 text-3xs font-bold text-white bg-slate-900/80 px-2.5 py-1 rounded-full border border-white/10 z-10 select-none pointer-events-none uppercase">
                    Vous
                  </span>
                </div>

                {/* Remote Partner Screen Area */}
                <div className="w-full max-w-sm aspect-video bg-slate-950 border border-white/10 rounded-3xl relative overflow-hidden flex flex-col items-center justify-center">
                  {/* Remote simulation avatar background or live animation */}
                  <div className="absolute inset-0 bg-gradient-to-tr from-slate-900 via-indigo-950 to-slate-900 opacity-60"></div>
                  
                  <div className="relative z-10 text-center space-y-3">
                    <img 
                      src={activeCall.partner.avatar} 
                      alt={activeCall.partner.name} 
                      className={`w-20 h-20 rounded-full object-cover border-2 border-indigo-500 mx-auto transition-transform ${
                        audioMeter > 45 ? 'scale-105 ring-4 ring-indigo-505/30' : ''
                      }`}
                    />
                    
                    <div className="space-y-1">
                      <p className="text-sm font-bold flex items-center justify-center gap-1">{activeCall.partner.name} {activeCall.partner.flag}</p>
                      <p className="text-2xs text-slate-400 uppercase tracking-wider font-bold">Niveau: {activeCall.partner.level}</p>
                    </div>

                    {/* Spectre simulated wave peak bar */}
                    <div className="flex justify-center items-center gap-1.5 h-6 mt-3">
                      <span className="w-1.5 bg-indigo-550 rounded-full transition-all duration-150" style={{ height: `${Math.max(4, audioMeter * 0.5)}px` }}></span>
                      <span className="w-1.5 bg-indigo-500 rounded-full transition-all duration-150" style={{ height: `${Math.max(4, audioMeter * 0.85)}px` }}></span>
                      <span className="w-1.5 bg-indigo-400 rounded-full transition-all duration-150" style={{ height: `${Math.max(4, audioMeter * 1.1)}px` }}></span>
                      <span className="w-1.5 bg-indigo-500 rounded-full transition-all duration-150" style={{ height: `${Math.max(4, audioMeter * 0.85)}px` }}></span>
                      <span className="w-1.5 bg-indigo-550 rounded-full transition-all duration-150" style={{ height: `${Math.max(4, audioMeter * 0.5)}px` }}></span>
                    </div>
                  </div>

                  {/* Remote overlay tag */}
                  <span className="absolute top-3 left-3 text-3xs font-bold text-white bg-slate-900/80 px-2.5 py-1 rounded-full border border-white/10 z-10 select-none pointer-events-none uppercase">
                    Partner
                  </span>
                </div>

              </div>

              {/* Sub-card pronunciation exercises while dialing/active conversation */}
              <div className="max-w-xl mx-auto w-full bg-white/5 border border-white/10 p-4 rounded-2xl mb-8 text-left leading-relaxed">
                <p className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest mb-1.5">Sujet de conversation suggéré :</p>
                <p className="text-xs text-slate-300">
                  "Let's describe our professional routine. Explain to your partner what your primary daily commute feels like, and how you currently touch base with colleagues about stakeholders."
                </p>
              </div>

              {/* Controller buttons */}
              <div className="max-w-md mx-auto w-full flex items-center justify-center gap-4 border-t border-white/5 pt-5 pb-3">
                {/* Micro */}
                <button 
                  onClick={() => setLocalMicMuted(!localMicMuted)}
                  className={`p-4 rounded-2xl transition border ${
                    localMicMuted 
                      ? 'bg-red-500 hover:bg-red-600 border-red-505' 
                      : 'bg-white/10 hover:bg-white/20 border-white/10 text-slate-100'
                  }`}
                  title={localMicMuted ? "Réactiver le microphone" : "Couper le son micro"}
                >
                  < volumeIcon micMuted={localMicMuted} />
                </button>

                {/* Red End Call */}
                <button 
                  onClick={endCall}
                  className="px-8 py-4 bg-red-600 hover:bg-red-700 font-bold rounded-2xl transition shadow-lg shadow-red-600/20"
                >
                  Raccrocher l'appel
                </button>

                {/* Camera toggle if video */}
                {activeCall.type === 'video' && (
                  <button 
                    onClick={() => setLocalCamMuted(!localCamMuted)}
                    className={`p-4 rounded-2xl transition border ${
                      localCamMuted 
                        ? 'bg-red-500 hover:bg-red-600 border-red-505' 
                        : 'bg-white/10 hover:bg-white/20 border-white/10 text-slate-100'
                    }`}
                    title={localCamMuted ? "Réactiver la caméra local" : "Désactiver la caméra local"}
                  >
                    < cameraIcon camMuted={localCamMuted} />
                  </button>
                )}
              </div>

            </div>
          )}

        </div>
      )}

    </div>
  );
}

// Inner Svg Icons and Small UI Helpers to Keep Applet Dependency-Lite
function ArrowIcon() {
  return (
    <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M5 12h14"></path>
      <path d="m12 5 7 7-7 7"></path>
    </svg>
  );
}

function volumeIcon({ micMuted }: { micMuted: boolean }) {
  if (micMuted) {
    return (
      <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <line x1="1" y1="1" x2="23" y2="23"></line>
        <path d="M9 9v3a3 3 0 0 0 5.12 2.12M15 9.34V4a3 3 0 0 0-5.94-.6"></path>
        <path d="M17 16.95A7 7 0 0 1 5 12v-2m14 0v2a7 7 0 0 1-.11 1.23"></path>
        <line x1="12" y1="19" x2="12" y2="23"></line>
        <line x1="8" y1="23" x2="16" y2="23"></line>
      </svg>
    );
  }
  return (
    <svg className="w-5 h-5 text-indigo-405" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"></path>
      <path d="M19 10v2a7 7 0 0 1-14 0v-2"></path>
      <line x1="12" y1="19" x2="12" y2="23"></line>
      <line x1="8" y1="23" x2="16" y2="23"></line>
    </svg>
  );
}

function cameraIcon({ camMuted }: { camMuted: boolean }) {
  if (camMuted) {
    return (
      <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M16 16v1a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h2m4 0h5a2 2 0 0 1 2 2v3m4-2.7L18.3 10"></path>
        <line x1="1" y1="1" x2="23" y2="23"></line>
      </svg>
    );
  }
  return (
    <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="m22 8-6 4 6 4V8Z"></path>
      <rect width="14" height="12" x="2" y="6" rx="2" ry="2"></rect>
    </svg>
  );
}
