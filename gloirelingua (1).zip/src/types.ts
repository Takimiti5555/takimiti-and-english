export type UserLevel = 'beginner' | 'advanced' | 'professional';

export type CategoryKey = 'grammar' | 'vocabulary' | 'spelling' | 'expressions' | 'idioms' | 'slang';

export interface CategoryDetail {
  id: CategoryKey;
  title: string;
  frenchTitle: string;
  description: string;
  icon: string;
  color: string;
  topics: Array<{
    title: string;
    description: string;
    examples?: string[];
  }>;
}

export interface Flashcard {
  id: string;
  word: string;
  type: string; // noun, verb, idiom, etc.
  translation: string;
  example: string;
  exampleTranslation: string;
  category: string;
}

export interface QuizQuestion {
  id: string;
  type: 'multiple' | 'input' | 'spelling' | 'translate' | 'listening';
  question: string;
  options?: string[];
  correctAnswer: string;
  audioText?: string; // For text-to-speech listening tasks
  explanation: string;
  context?: string;
}

export interface ExerciseSession {
  category: CategoryKey;
  title: string;
  questions: QuizQuestion[];
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  text: string;
  timestamp: string;
  fileUrl?: string;
  fileName?: string;
}

export interface ChatRoom {
  id: string;
  name: string;
  avatar: string;
  isGroup: boolean;
  messages: ChatMessage[];
  members: number;
}

export interface FriendProfile {
  id: string;
  name: string;
  level: UserLevel;
  country: string;
  flag: string;
  interests: string[];
  avatar: string;
  isOnline: boolean;
  score: number;
}

export interface Challenge {
  id: string;
  title: string;
  type: 'vocabulary' | 'pronunciation' | 'listening' | 'reading' | 'grammar' | 'spelling' | 'idioms';
  description: string;
  points: number;
  badge: string;
  completed: boolean;
}

export interface TestResult {
  id: string;
  date: string;
  score: number;
  estimatedLevel: UserLevel;
  breakdown: {
    reading: number;
    writing: number;
    listening: number;
    speaking: number;
    grammar: number;
    vocabulary: number;
  };
  analysis: string;
}

export interface UserStats {
  score: number;
  level: UserLevel;
  learningTimeMinutes: number;
  testsCompletedCount: number;
  challengesCompletedCount: number;
  vocabularyMasteredCount: number;
  grammarSolvedCount: number;
  attendanceStreak: number;
  badges: string[];
}
