import express from "express";
import path from "path";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware for body parsing
  app.use(express.json());

  // Initialize Gemini API client on the server side
  const apiKey = process.env.GEMINI_API_KEY;
  
  let ai: GoogleGenAI | null = null;
  if (apiKey) {
    ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  } else {
    console.warn("⚠️ Warning: GEMINI_API_KEY environment variable is not defined!");
  }

  // -------------------------------------------------------------
  // API Routes
  // -------------------------------------------------------------
  
  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", time: new Date().toISOString(), hasAi: !!ai });
  });

  // AI Assistant Tutor Endpoint
  // Handles conversational Q&As, general rule explanations, phrase corrections, and translation.
  app.post("/api/chat", async (req, res) => {
    try {
      if (!ai) {
        return res.status(500).json({ 
          error: "Clé API Gemini non configurée sur le serveur. Veuillez configurer les secrets dans l'onglet Settings." 
        });
      }

      const { messages, userLevel } = req.body;
      
      if (!messages || !Array.isArray(messages)) {
        return res.status(400).json({ error: "Messages array is required." });
      }

      // Constrain history to the last 10 messages for token friendliness and context
      const contextMessages = messages.slice(-10).map((msg: any) => {
        return `${msg.role === 'user' ? 'Étudiant' : 'Assistant English Master'}: ${msg.content}`;
      }).join("\n");

      const prompt = `L'étudiant actuel a le niveau d'anglais suivant : ${userLevel || 'beginner'}.\nVoici l'historique de leur discussion :\n${contextMessages}\n\nRéponds au dernier message de l'étudiant de manière pédagogique, positive et claire. Fournis des explications claires en français avec de nombreux exemples concrets en anglais. Si l'étudiant a fait des fautes d'orthographe ou de grammaire dans son message, fais une petite section 'Correction' bienveillante en gras.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          systemInstruction: "Tu es 'English Master AI', un tuteur d'anglais exceptionnel d'un niveau académique mais bienveillant. Ton rôle est d'aider les apprenants (francophones) à s'améliorer en grammaire, vocabulaire, orthographe, expressions idiomatiques ou anglais des affaires. Garde des explications structurées, encourageantes, et utilise du Markdown propre (listes, gras) pour rendre l'apprentissage facile.",
          temperature: 0.7,
        }
      });

      res.json({ content: response.text });
    } catch (error: any) {
      console.error("Gemini API Error in /api/chat:", error);
      res.status(500).json({ error: error.message || "Erreur interne lors du traitement par l'IA." });
    }
  });

  // Text correction & analysis tool (used in spelling exercises or custom user text evaluations)
  app.post("/api/correct", async (req, res) => {
    try {
      if (!ai) {
        return res.status(500).json({ 
          error: "Service de correction IA non disponible sans clé API." 
        });
      }

      const { text, userLevel } = req.body;
      if (!text) {
        return res.status(400).json({ error: "Du texte est requis pour la correction." });
      }

      const prompt = `Analyse et corrige le texte anglais suivant écrit par un apprenant de niveau ${userLevel || 'beginner'} :\n"${text}"\n\nDonne :\n1. Une version entièrement corrigée et naturelle.\n2. La liste claire des types de fautes commises (grammaire, orthographe, style, ponctuation) expliquées en français.\n3. Une note pédagogique d'encouragement.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          systemInstruction: "Tu es un correcteur d'anglais professionnel. Tu analyses les textes en détail avec précision, discernement et pédagogie.",
        }
      });

      res.json({ analysis: response.text });
    } catch (error: any) {
      console.error("Gemini API Error in /api/correct:", error);
      res.status(500).json({ error: error.message || "Erreur interne d'analyse linguistique." });
    }
  });

  // -------------------------------------------------------------
  // Vite Integration for Asset Serving
  // -------------------------------------------------------------
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  // -------------------------------------------------------------
  // Start Server
  // -------------------------------------------------------------
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
